var content=function(){"use strict";var Ke=Object.defineProperty;var Xe=(P,I,R)=>I in P?Ke(P,I,{enumerable:!0,configurable:!0,writable:!0,value:R}):P[I]=R;var O=(P,I,R)=>Xe(P,typeof I!="symbol"?I+"":I,R);var he,fe;function P(i){return i}const I=[{id:"auto_scroll",emoji:"⏩",label:"Auto Scroll",matches:[]},{id:"brain_rot",emoji:"🧠💀",label:"Brain Rot",matches:["brain_rot","food_porn"]},{id:"cooking",emoji:"🍳",label:"Cooking",matches:["cooking"]},{id:"laugh",emoji:"😂",label:"Laugh",matches:["comedy"]},{id:"larp",emoji:"💎",label:"LARP",matches:["larp"]},{id:"fitness",emoji:"💪",label:"Fitness",matches:["fitness"]},{id:"baddies",emoji:"💅",label:"Baddies",matches:["baddies"]},{id:"custom",emoji:"✨",label:"Custom",matches:[]}],R=new Set(["fyp","foryoupage","foryou","viral","trending","parati","xyzbca"]),Te={cooking:{keywords:["recipe","how to make","how to cook","ingredients:","preheat","simmer for","sauté","whisk together","fold in","minutes at","stir in","bake at"],hashtags:["cookingtiktok","easyrecipe","recipevideo","cookingclass","cheflife","kitchenhacks"]},educational:{keywords:["how to","tutorial","explained","tip:","did you know","pro tip","lesson","fact:","in this video"],hashtags:["learnontiktok","edutok","studytok","didyouknow","sciencetok","history","tutorial"]},comedy:{keywords:["skit","pov:","when you","when my","me when","tell me without telling me","pov when"],hashtags:["comedy","funny","humor","jokes","meme","lmao"]},fitness:{keywords:["shirtless","pump","pump cover","gym session","workout","deadlift","squat","bench press","chest day","back day","leg day","arm day","lifting","gainz","shredded","physique","natty","mens physique","bodybuilding","cutting","bulking","reps","sets","rep range","gym pr","six pack","aesthetic gym","gym flex","flexing muscle"],hashtags:["gymtok","fittok","fitness","gymrat","bodybuilding","physique","gainz","gym","gymflex","shredded","mensphysique","womensphysique","natty","lifting","fitfam","fitspo","workout","gymmotivation","gymlife","chestday","backday","legday","pumpcover","sixpack","aestheticgym","gymbros","gymtransformation"]},baddies:{keywords:["baddie","bad bitch","pretty privilege","glam","glow up","outfit of the day","ootd","fit check","feeling cute","baddie aesthetic","gym girl","fit girl","gym fit","how she walks","just girls"],hashtags:["baddie","baddies","baddietok","baddievibes","baddieaesthetic","badbitch","badbitchenergy","fitgirl","fitgirls","gymgirl","gymgirls","gymbaddie","glam","glamour","glammakeup","ootd","fashiongirl","fashionista","fitcheck","fitcheckdaily","glowup","glowupchallenge","instabaddie","baddiesonly","thatgirl","cleangirl","cleangirlaesthetic","softgirl","gymgirlaesthetic","gymgirlfit"]},motivational:{keywords:["grind","success","never give up","mindset","discipline","hustle","mentality"],hashtags:["motivation","sigma","mindset","success","entrepreneur","inspiration"]},brain_rot:{keywords:["skibidi","skibidi toilet","sigma","gigachad","gyatt","rizz","ohio","fanum","mewing","looksmax","looksmaxxing","subway surfers","minecraft parkour","ai voice","ai narrator","ai voiceover","peter griffin","family guy edit","stewie","spongebob edit","simpsons edit","anime edit","animeedit"],hashtags:["skibidi","skibiditoilet","brainrot","sigma","sigmaedit","sigmamale","gigachad","gyatt","rizz","ohio","fanumtax","mewing","looksmaxxing","aigenerated","aivoice","aivideo","aishorts","airelaxing","familyguy","familyguyedit","peterstewieedit","petergriffin","spongebob","spongebobedit","simpsonsedit","rickandmorty","phonk","phonky","phonkedit","phonkmusic","animeedit","animeedits","manhwa","manhwaedit","subwaysurfers","minecraftparkour","parkour","edit","edits","cope","slop","sloppost","ragebait"]},wholesome:{keywords:["rescued","wholesome","made my day","good news"],hashtags:["wholesome","cute","feelgood","adoption","kindness"]},food_porn:{keywords:[],hashtags:["foodporn","food","yummy","tasty","foodie"]},larp:{keywords:["lamborghini","lambo","ferrari","mclaren","rolls royce","bentley","aventador","huracan","urus","g wagon","g-wagon","g63","rolex","patek philippe","audemars piguet","richard mille","birkin","louis vuitton","hermes bag","gucci flex","secured the bag","first million","made my first million","luxury lifestyle","i'm rich","i'm so rich","rich kid","private jet","mansion tour","penthouse tour","andrew tate","tristan tate","iman gadzhi","tai lopez","grant cardone","alpha male","sigma grindset","high value man"],hashtags:["lambo","lamborghini","ferrari","mclaren","bentley","rollsroyce","supercar","supercars","exoticcars","exoticcar","sportscar","sportscars","luxurycar","luxurycars","aventador","huracan","urus","gwagon","g63","rolex","rolexwatch","patekphilippe","audemarspiguet","richardmille","luxurywatches","birkin","hermesbirkin","louisvuitton","gucciflex","luxurylifestyle","richlife","millionairelifestyle","billionairelifestyle","millionaire","billionaire","andrewtate","tristantate","sigmamale","alphamale","sigmagrindset","sigmaedit","highvalueman","imanagadzhi","tailopez","grantcardone","flex","moneyflex","getrichquick","privatejet","oldmoney","newmoney","hustlegrindset"]},startup:{keywords:["startup","founder","y combinator"," yc ","seed round","series a","mvp","product market fit","pmf","fundraising","pitch deck","launching","building in public","saas","indie hacker"],hashtags:["startup","startups","founder","founders","ycombinator","yc","startuplife","entrepreneur","saas","indiehackers","buildinpublic","techstartup","siliconvalley","techtok"]}};function Ce(i,o,c){const d=o.map(x=>x.toLowerCase().replace(/^#/,"")).filter(x=>!R.has(x)),v=((i||"")+" "+(c||"")).toLowerCase(),b={};for(const[x,k]of Object.entries(Te)){let y=0;for(const V of k.keywords)v.includes(V)&&(y+=2);for(const V of k.hashtags)d.includes(V)&&(y+=3);y>0&&(b[x]=y)}const C=Object.entries(b).sort((x,k)=>k[1]-x[1]);if(!C.length)return{category:null,confidence:0};const[M,H]=C[0];return{category:M,confidence:Math.min(H/6,.95)}}const Le={matches:["https://www.tiktok.com/*"],main(){const i={videoSelector:"video",itemSelector:'[data-e2e="recommend-list-item-container"]',captionSelector:'[data-e2e="video-desc"]',audioSelector:'[data-e2e="video-music"]',creatorSelector:'a[href^="/@"]',likeIconSelector:'[data-e2e="like-icon"]',likeAriaSelector:'button[aria-label*="Like" i]',scrollContainerId:"column-list-container",minVideoHeight:200,decisionIntervalMs:1500,tickIntervalMs:500,likeDelayMinMs:4e3,likeDelayJitterMs:3e3,likeProbability:.55,likeRateLimitWindowMs:36e5,likeRateLimitMax:20};let o=null,c="",d=!0,v=!1,b=!1,C=0,M=null;const H=new Set,x=[];let k="training";const y=[],V=10,_e=.6,Ne=.4,ze={decisionIntervalMs:300,likeProbability:1,useFrames:!1},$e={decisionIntervalMs:2500,likeProbability:.3,useFrames:!0},ne=()=>k==="training"?ze:$e,Oe={brain_rot:2500,food_porn:4e3,baddies:5e3,comedy:5500,fitness:7e3,larp:7500,motivational:8e3,wholesome:7500,wind_down:9e3,cooking:1e4,news_politics:11e3,educational:13e3,startup:13e3,drama_storytime:15e3,other:6e3};function Pe(e){return Oe[e||"other"]||6e3}function be(e,t){const a=Pe(e),r=t!=null&&t.duration&&isFinite(t.duration)&&t.duration>0?Math.floor(t.duration*1e3):0;if(r>0){const s=Math.max(2500,Math.floor(r*.92));return Math.min(a,s)}return a}let T=0,A=0;setInterval(()=>{if(T===0||!o||o==="auto_scroll")return;const e=_();if(!(!e||!e.currentSrc)){if(A>0&&e.currentTime+.5<A){console.log("[MoodScroll] video looped, advancing immediately"),T=0,A=0,N(e.currentSrc);return}if(e.duration&&e.currentTime>e.duration-.5){console.log("[MoodScroll] video about to loop, advancing now"),T=0,A=0,N(e.currentSrc);return}A=e.currentTime}},250);const Q=new Set(["larp","baddies","fitness","brain_rot"]),Re={startup:["dance","dancing","makeup","beauty","fashion","outfit","nails","hair","asmr","slime","satisfying","cat","cats","dog","dogs","pets","animals","food","foodporn","cooking","recipe","foodtok","restaurant","workout","gym","gymtok","fitness","bodybuilding","pov","skit","comedy","funny","meme","humor","jokes","prank","storytime","gossip","drama","tea","relationship","sports","football","basketball","soccer","nba","nfl","music","song","singing","dance challenge","lifehack","travel","wedding","gaming","minecraft","fortnite"],learn:["dance","makeup","beauty","fashion","outfit","nails","comedy","funny","meme","humor","jokes","pov","skit","asmr","slime","satisfying","prank","storytime","gossip","drama","tea","relationship","gaming","sports","wedding","travel"],cooking:["dance","makeup","beauty","fashion","outfit","nails","workout","gym","fitness","bodybuilding","startup","business","finance","crypto","stocks","asmr","slime","sleep","pov","skit","comedy","funny","meme","prank","gaming","sports","music","singing","travel","wedding","tutorial"],laugh:["recipe","cooking","foodtok","workout","gym","fitness","cardio","tutorial","study","studytok","history","science","edu","startup","business","finance","investing","crypto","news","politics","asmr","sleep","wholesome"],hype:["asmr","slime","sleep","wholesome","cooking","recipe","foodtok","startup","tutorial","study","sad","cry","breakup","gossip","drama","storytime","news","politics","gaming"],wind_down:["workout","gym","fitness","cardio","hiit","hustle","grind","startup","business","finance","comedy","meme","prank","funny","news","politics","sports","gaming","fortnite","minecraft","dance challenge","shock","fight"],brain_rot:["startup","business","finance","tutorial","study","history","science","edu","learnontiktok","news","politics","documentary"],food_porn:["dance","workout","gym","startup","finance","tutorial","study","history","science","sports","gaming","news","politics","comedy","skit","pov"],larp:["cooking","recipe","foodtok","dance","dancing","makeup","beauty","nails","hair","comedy","meme","skit","prank","tutorial","study","history","science","edu","gaming","minecraft","fortnite","asmr","slime","sleep","wholesome","news","politics"],fitness:["cooking","recipe","foodtok","startup","business","finance","crypto","tutorial","study","history","science","edu","gaming","minecraft","fortnite","asmr","slime","sleep","wholesome","news","politics","comedy","meme","skit","prank","dance challenge"],baddies:["cooking","recipe","foodtok","startup","business","finance","crypto","tutorial","study","history","science","edu","gaming","minecraft","fortnite","asmr","slime","sleep","news","politics","wholesome","family"]};chrome.storage.local.get(["currentMode","customDescription","autoEngage","sidekickActive"]).then(e=>{o=e.currentMode||null,c=e.customDescription||"",d=e.autoEngage!==!1,v=!!e.sidekickActive,v&&ye(),B()}),chrome.runtime.onMessage.addListener(e=>{e.type==="set_mode"&&(o=e.mode,M=null,le(),B()),e.type==="stop"&&(o=null,M=null,le(),B())});function ye(){if(document.getElementById("moodscroll-sidekick-css"))return;const e=document.createElement("style");e.id="moodscroll-sidekick-css",e.textContent=`
        /* HARD HIDES: all nav + header chrome */
        [data-e2e="nav-foryou"], [data-e2e="nav-following"], [data-e2e="nav-explore"],
        [data-e2e="nav-live"], [data-e2e="nav-shop"], [data-e2e="nav-profile"],
        [data-e2e="nav-upload"], [data-e2e="nav-more-menu"], [data-e2e="nav-search"],
        [data-e2e="search-box"], [data-e2e="search-box-button"],
        [data-e2e="top-login-button"], [data-e2e="top-right-action-bar-get-coin"],
        [data-e2e="tiktok-logo"],
        /* Right-side engagement column (like/comment/share/follow/save) */
        [data-e2e="like-icon"], [data-e2e="like-count"],
        [data-e2e="comment-icon"], [data-e2e="comment-count"],
        [data-e2e="share-icon"], [data-e2e="share-count"],
        [data-e2e="favorite-icon"], [data-e2e="favorite-count"],
        [data-e2e="feed-follow"], [data-e2e="video-author-avatar"],
        [data-e2e="more-menu-icon"], [data-e2e="see-more-icon"],
        /* Caption / music / desc overlays */
        [data-e2e="video-desc"], [data-e2e="video-music"], [data-e2e="capcut-tag"],
        [data-e2e^="desc-span"], [data-e2e="copyright"],
        /* Sidebars + the whole left column */
        [class*="DivSideNavContainer"], [class*="DivHeaderContainer"],
        [class*="DivLeftContainer"], [class*="DivSidebarContainer"],
        [class*="DivTabMenuContainer"], aside, header {
          display: none !important; width: 0 !important; height: 0 !important;
        }
        /* Compress horizontal margins so video fills the window */
        #column-list-container, [class*="DivColumnL"] {
          margin: 0 auto !important; padding: 0 !important;
        }
        body, html {
          background: #000 !important;
        }
        /* Strip TikTok's gradient overlays that darken the bottom of the video */
        [class*="DivBottomShadow"], [class*="DivVideoInfoContainer"],
        [class*="DivVideoCardContainer"] > div[class*="DivBottom"] {
          display: none !important;
        }
        /* Mood Scroll's own collapsed button stays visible (z-index 2^31) */
      `,document.head.appendChild(e)}function He(){var e;(e=document.getElementById("moodscroll-sidekick-css"))==null||e.remove()}let D=null,l=null;function re(){D&&document.documentElement.contains(D)||(D=document.createElement("div"),D.id="moodscroll-overlay-root",D.style.cssText="all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none;",l=D.attachShadow({mode:"open"}),l.innerHTML=Fe(),document.documentElement.appendChild(D),je(),B(),de())}function Fe(){return`
<style>
  :host {
    all: initial;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', system-ui, sans-serif;
    --bg-base: rgba(22, 22, 24, 0.78);
    --bg-elevated: rgba(255, 255, 255, 0.05);
    --bg-elevated-hover: rgba(255, 255, 255, 0.09);
    --border-subtle: rgba(255, 255, 255, 0.08);
    --border-strong: rgba(255, 255, 255, 0.16);
    --text-primary: rgba(255, 255, 255, 0.95);
    --text-secondary: rgba(255, 255, 255, 0.58);
    --text-tertiary: rgba(255, 255, 255, 0.36);
    --accent: #ffd75a;
    --accent-rich: linear-gradient(180deg, #ffe07a 0%, #ffc83d 100%);
    --success: #34d399;
    --success-rich: linear-gradient(180deg, #4ade80 0%, #22c55e 100%);
    --danger: #f87171;
    --danger-rich: linear-gradient(180deg, #fb7185 0%, #e11d48 100%);
    --purple: #a78bfa;
    --purple-rich: linear-gradient(180deg, #c4b5fd 0%, #8b5cf6 100%);
    --spring: cubic-bezier(0.32, 1.45, 0.6, 1);
    --ease: cubic-bezier(0.4, 0, 0.2, 1);
  }
  * { box-sizing: border-box; font-family: inherit; -webkit-font-smoothing: antialiased; }

  /* ---------- FLOATING TOGGLE ---------- */
  .ms-toggle {
    position: fixed; bottom: 80px; right: 20px; width: 52px; height: 52px;
    border-radius: 50%;
    background: linear-gradient(180deg, rgba(50,50,55,0.85), rgba(22,22,24,0.85));
    color: var(--text-primary);
    border: 0.5px solid rgba(255,255,255,0.18);
    cursor: pointer; font-size: 22px; line-height: 1;
    box-shadow:
      inset 0 1px 0 rgba(255,255,255,0.12),
      inset 0 -1px 0 rgba(0,0,0,0.3),
      0 8px 24px rgba(0,0,0,0.5),
      0 1px 2px rgba(0,0,0,0.3);
    transition: transform 0.25s var(--spring), box-shadow 0.25s var(--ease), background 0.25s var(--ease);
    display: flex; align-items: center; justify-content: center;
    pointer-events: auto;
    backdrop-filter: blur(24px) saturate(180%);
    -webkit-backdrop-filter: blur(24px) saturate(180%);
  }
  .ms-toggle:hover { transform: translateY(-2px) scale(1.05); box-shadow: inset 0 1px 0 rgba(255,255,255,0.15), inset 0 -1px 0 rgba(0,0,0,0.3), 0 12px 32px rgba(0,0,0,0.6); }
  .ms-toggle:active { transform: scale(0.95); }
  .ms-toggle.active {
    background: var(--accent-rich);
    color: #1a1500; border-color: rgba(255, 217, 90, 0.5);
    box-shadow:
      0 0 0 4px rgba(255, 217, 90, 0.12),
      0 8px 32px rgba(255, 217, 90, 0.35),
      inset 0 1px 0 rgba(255,255,255,0.4);
  }
  .ms-toggle .ms-pulse {
    position: absolute; inset: -8px; border-radius: 50%;
    border: 1.5px solid var(--accent); opacity: 0; pointer-events: none;
    animation: msPulse 2.4s var(--ease) infinite;
  }
  .ms-toggle.active .ms-pulse { opacity: 1; }
  @keyframes msPulse {
    0% { transform: scale(0.85); opacity: 0.9; }
    100% { transform: scale(1.6); opacity: 0; }
  }

  /* ---------- DECISION FLASH ---------- */
  .ms-flash {
    position: fixed; bottom: 148px; right: 20px;
    padding: 9px 16px; border-radius: 100px;
    font-size: 11.5px; font-weight: 600; letter-spacing: -0.01em;
    pointer-events: none; opacity: 0;
    transform: translateY(8px);
    transition: all 0.4s var(--spring);
    backdrop-filter: blur(20px) saturate(180%);
    box-shadow: 0 8px 24px rgba(0,0,0,0.35);
    border: 0.5px solid rgba(255,255,255,0.15);
  }
  .ms-flash.show { opacity: 1; transform: translateY(0); }
  .ms-flash.match { background: var(--success-rich); color: #042818; }
  .ms-flash.skip { background: var(--danger-rich); color: #ffffff; }

  /* ---------- LOCKED-IN CELEBRATION BANNER ---------- */
  .ms-locked-banner {
    position: fixed; top: 50%; left: 50%;
    transform: translate(-50%, -50%) scale(0.85);
    background: linear-gradient(180deg, rgba(20, 50, 32, 0.95), rgba(15, 35, 22, 0.95));
    color: #4ade80;
    border: 1px solid rgba(74, 222, 128, 0.4);
    border-radius: 20px; padding: 28px 40px;
    box-shadow: 0 0 0 4px rgba(74, 222, 128, 0.12), 0 32px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.08);
    backdrop-filter: blur(28px) saturate(180%);
    -webkit-backdrop-filter: blur(28px) saturate(180%);
    pointer-events: none; opacity: 0;
    z-index: 2147483647;
    transition: opacity 0.5s var(--ease), transform 0.6s var(--spring);
    text-align: center; min-width: 320px;
  }
  .ms-locked-banner.show { opacity: 1; transform: translate(-50%, -50%) scale(1); }
  .ms-locked-icon { font-size: 56px; line-height: 1; margin-bottom: 10px; }
  .ms-locked-title { font-size: 22px; font-weight: 700; letter-spacing: -0.02em;
    background: linear-gradient(180deg, #fff, #4ade80); -webkit-background-clip: text;
    -webkit-text-fill-color: transparent; margin-bottom: 6px; }
  .ms-locked-sub { font-size: 13px; color: rgba(255,255,255,0.65); letter-spacing: -0.005em; }

  /* ---------- PANEL ---------- */
  .ms-panel {
    position: fixed; bottom: 148px; right: 20px; width: 304px;
    background: var(--bg-base);
    color: var(--text-primary);
    border: 0.5px solid var(--border-subtle);
    border-radius: 18px; padding: 16px 14px 14px;
    box-shadow:
      0 0 0 0.5px rgba(0,0,0,0.5),
      0 40px 100px -10px rgba(0,0,0,0.75),
      inset 0 0.5px 0 rgba(255,255,255,0.07);
    backdrop-filter: blur(48px) saturate(200%);
    -webkit-backdrop-filter: blur(48px) saturate(200%);
    display: none; pointer-events: auto;
    transform-origin: bottom right;
    opacity: 0; transform: translateY(8px) scale(0.96);
    transition: opacity 0.28s var(--ease), transform 0.32s var(--spring);
  }
  .ms-panel.open { display: block; opacity: 1; transform: translateY(0) scale(1); }

  .ms-header {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 2px;
  }
  .ms-title {
    font-size: 15px; font-weight: 600; letter-spacing: -0.02em;
    color: var(--text-primary);
  }
  .ms-close {
    background: rgba(255,255,255,0.06);
    color: var(--text-tertiary); border: none; cursor: pointer;
    font-size: 13px; line-height: 1; padding: 0;
    width: 22px; height: 22px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    transition: all 0.18s var(--ease);
  }
  .ms-close:hover { background: rgba(255,255,255,0.14); color: var(--text-primary); }
  .ms-subtitle {
    font-size: 11px; color: var(--text-tertiary);
    margin-bottom: 12px; letter-spacing: -0.005em;
  }

  /* ---------- MODE GRID ---------- */
  .ms-grid {
    display: grid; grid-template-columns: 1fr 1fr; gap: 5px; margin-bottom: 10px;
  }
  .ms-mode {
    background: rgba(255,255,255,0.04);
    color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle);
    border-radius: 9px; padding: 9px 9px;
    cursor: pointer;
    display: flex; align-items: center; gap: 7px;
    font-size: 11.5px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease), transform 0.16s var(--spring);
  }
  .ms-mode:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }
  .ms-mode:active { transform: scale(0.97); }
  .ms-mode.active {
    background: linear-gradient(180deg, #ffe07a 0%, #ffc83d 100%);
    color: #1a1500;
    border-color: transparent;
    box-shadow: 0 2px 10px rgba(255, 217, 90, 0.28), inset 0 1px 0 rgba(255,255,255,0.4);
    font-weight: 600;
  }
  .ms-emoji { font-size: 15px; line-height: 1; flex-shrink: 0; }
  .ms-label { font-size: 11.5px; }

  /* ---------- CUSTOM INPUT ---------- */
  .ms-custom-wrap { margin-bottom: 12px; display: none; }
  .ms-custom-wrap.show { display: block; animation: msSlideDown 0.32s var(--spring); }
  @keyframes msSlideDown { from { opacity: 0; transform: translateY(-6px); max-height: 0; } to { opacity: 1; transform: translateY(0); max-height: 80px; } }
  .ms-custom-input {
    width: 100%; padding: 11px 13px;
    background: rgba(255,255,255,0.05); color: var(--text-primary);
    border: 0.5px solid var(--border-subtle);
    border-radius: 10px; font-size: 13px;
    font-family: inherit; letter-spacing: -0.01em;
    box-sizing: border-box;
    transition: all 0.2s var(--ease);
  }
  .ms-custom-input::placeholder { color: var(--text-tertiary); }
  .ms-custom-input:focus {
    outline: none; border-color: var(--accent);
    background: rgba(255,255,255,0.08);
    box-shadow: 0 0 0 3px rgba(255, 217, 90, 0.1);
  }
  .ms-custom-hint {
    font-size: 10.5px; color: var(--text-tertiary);
    margin-top: 6px; padding-left: 2px; letter-spacing: -0.005em;
  }

  /* ---------- ACTIVE LINE ---------- */
  .ms-active-line {
    font-size: 11px; padding: 8px 11px;
    background: rgba(52,211,153,0.07); color: var(--success);
    border: 0.5px solid rgba(52,211,153,0.18);
    border-radius: 9px; margin-bottom: 10px;
    letter-spacing: -0.005em; display: none;
  }
  .ms-active-line.show { display: block; }
  .ms-active-line b { color: white; font-weight: 600; }

  /* ---------- PHASE INDICATOR ---------- */
  .ms-phase {
    background: rgba(255,255,255,0.04);
    border: 0.5px solid var(--border-subtle);
    border-radius: 12px; padding: 10px 12px; margin-bottom: 12px;
    display: none;
  }
  .ms-phase.show { display: block; }
  .ms-phase-row {
    display: flex; justify-content: space-between; align-items: center;
    font-size: 11.5px; margin-bottom: 7px; letter-spacing: -0.01em;
  }
  .ms-phase-label {
    color: var(--text-primary); font-weight: 500;
    display: flex; align-items: center; gap: 6px;
  }
  .ms-phase-label::before {
    content: ''; width: 6px; height: 6px; border-radius: 50%;
    background: var(--accent); box-shadow: 0 0 8px var(--accent);
    animation: msBlink 1.4s ease-in-out infinite;
  }
  .ms-phase.stable .ms-phase-label::before {
    background: var(--success); box-shadow: 0 0 8px var(--success); animation: none;
  }
  @keyframes msBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
  .ms-phase-stat { color: var(--text-tertiary); font-variant-numeric: tabular-nums; font-size: 11px; }
  .ms-phase-bar {
    height: 4px; background: rgba(255,255,255,0.08); border-radius: 100px; overflow: hidden;
  }
  .ms-phase-fill {
    height: 100%; width: 0%;
    background: linear-gradient(90deg, var(--accent), var(--success));
    border-radius: 100px;
    transition: width 0.6s var(--ease);
  }
  .ms-phase.stable .ms-phase-fill { background: var(--success); }

  /* ---------- STATS — minimal inline strip ---------- */
  .ms-stats {
    display: flex; justify-content: space-between;
    padding: 7px 4px;
    margin-bottom: 10px;
    font-size: 10.5px; color: var(--text-tertiary);
    letter-spacing: 0;
    border-top: 0.5px solid var(--border-subtle);
    border-bottom: 0.5px solid var(--border-subtle);
  }
  .ms-stat-cell {
    display: flex; align-items: baseline; gap: 4px;
  }
  .ms-stat-cell b {
    color: var(--text-primary); font-weight: 600; font-size: 12px;
    font-variant-numeric: tabular-nums; letter-spacing: -0.015em;
  }
  .ms-stat-cell span { font-size: 10.5px; color: var(--text-tertiary); }

  /* ---------- ENGAGE TOGGLE ROW ---------- */
  .ms-toggle-row {
    display: flex; align-items: center; justify-content: space-between;
    font-size: 11px; padding: 3px 2px; margin-bottom: 10px;
    color: var(--text-secondary); letter-spacing: -0.005em;
  }
  .ms-switch { position: relative; display: inline-block; width: 30px; height: 18px; }
  .ms-switch input { opacity: 0; width: 0; height: 0; }
  .ms-slider {
    position: absolute; cursor: pointer; inset: 0;
    background: rgba(255,255,255,0.12);
    border-radius: 18px; transition: background 0.22s var(--ease);
  }
  .ms-slider::before {
    position: absolute; content: ""; height: 14px; width: 14px;
    left: 2px; top: 2px; background: white;
    border-radius: 50%; transition: transform 0.26s var(--spring);
    box-shadow: 0 1px 3px rgba(0,0,0,0.35);
  }
  input:checked + .ms-slider { background: var(--success); }
  input:checked + .ms-slider::before { transform: translateX(12px); }

  /* ---------- LAYOUT BUTTONS ---------- */
  .ms-sidekick-row { display: grid; grid-template-columns: 1.6fr 1fr; gap: 5px; margin-bottom: 6px; }
  .ms-sidekick-btn {
    padding: 9px 6px;
    background: rgba(255,255,255,0.04); color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle); border-radius: 8px;
    cursor: pointer; font-family: inherit;
    font-size: 11px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease);
  }
  /* The primary Phone Mode button — slightly bigger, accent-colored */
  .ms-phone-btn {
    background: rgba(255, 217, 90, 0.08) !important;
    color: var(--accent) !important;
    border-color: rgba(255, 217, 90, 0.22) !important;
    font-weight: 600 !important;
  }
  .ms-phone-btn:hover {
    background: rgba(255, 217, 90, 0.14) !important;
    border-color: rgba(255, 217, 90, 0.4) !important;
  }
  .ms-phone-btn.active {
    background: linear-gradient(180deg, #ffe07a, #ffc83d) !important;
    color: #1a1500 !important;
    border-color: transparent !important;
    box-shadow: 0 2px 10px rgba(255, 217, 90, 0.28), inset 0 1px 0 rgba(255,255,255,0.35);
  }
  .ms-sidekick-btn:hover {
    background: rgba(167, 139, 250, 0.09); color: var(--purple);
    border-color: rgba(167, 139, 250, 0.25);
  }
  .ms-sidekick-btn.active:not(.ms-phone-btn) {
    background: linear-gradient(180deg, #c4b5fd, #8b5cf6); color: white;
    border-color: transparent;
    box-shadow: 0 2px 10px rgba(167, 139, 250, 0.28), inset 0 1px 0 rgba(255,255,255,0.22);
  }

  /* ---------- ACTIONS ---------- */
  .ms-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; margin-bottom: 5px; }
  .ms-stop, .ms-receipt-btn {
    padding: 8px;
    background: rgba(255,255,255,0.04); color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle); border-radius: 8px;
    cursor: pointer; font-family: inherit;
    font-size: 11px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease);
  }
  .ms-receipt-btn:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }
  .ms-stop:hover {
    background: rgba(248,113,113,0.09); color: var(--danger);
    border-color: rgba(248,113,113,0.25);
  }
  .ms-reset-btn {
    width: 100%; padding: 8px;
    background: rgba(255,255,255,0.04); color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle); border-radius: 8px;
    cursor: pointer; font-family: inherit;
    font-size: 11px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease);
  }
  .ms-reset-btn:hover {
    background: rgba(255,217,90,0.08); color: var(--accent);
    border-color: rgba(255,217,90,0.25);
  }
</style>
<button class="ms-toggle" id="ms-toggle" title="Mood Scroll — click to open"><span class="ms-pulse"></span><span id="ms-toggle-icon">✨</span></button>
<div class="ms-flash" id="ms-flash"></div>
<div class="ms-locked-banner" id="ms-locked-banner">
  <div class="ms-locked-icon">🎯</div>
  <div class="ms-locked-title">LOCKED IN</div>
  <div class="ms-locked-sub">Algorithm tuned · scrolling at natural pace</div>
</div>
<div class="ms-panel" id="ms-panel">
  <div class="ms-header">
    <span class="ms-title">Mood Scroll</span>
    <button class="ms-close" id="ms-close">×</button>
  </div>
  <div class="ms-subtitle">pick a mood — i'll filter the feed</div>
  <div class="ms-grid">${I.map(t=>`<button class="ms-mode" data-mode="${t.id}"><span class="ms-emoji">${t.emoji}</span><span class="ms-label">${t.label}</span></button>`).join("")}</div>
  <div class="ms-custom-wrap" id="ms-custom-wrap">
    <input class="ms-custom-input" id="ms-custom-input" type="text" placeholder="describe what you want..." maxlength="200" />
    <div class="ms-custom-hint">enter to activate · examples: "startup founders", "60s rock", "golden retrievers"</div>
  </div>
  <div class="ms-active-line" id="ms-active-line">Active: <b id="ms-active-text"></b></div>
  <div class="ms-phase" id="ms-phase">
    <div class="ms-phase-row">
      <span class="ms-phase-label" id="ms-phase-label">Training the algo</span>
      <span class="ms-phase-stat" id="ms-phase-stat">0/0 matched</span>
    </div>
    <div class="ms-phase-bar"><div class="ms-phase-fill" id="ms-phase-fill"></div></div>
  </div>
  <div class="ms-stats">
    <div class="ms-stat-cell"><b id="ms-timer">0:00</b></div>
    <div class="ms-stat-cell"><b id="ms-watched">0</b><span>watched</span></div>
    <div class="ms-stat-cell"><b id="ms-skipped">0</b><span>skipped</span></div>
  </div>
  <div class="ms-toggle-row">
    <span>train algo (auto-like matches)</span>
    <label class="ms-switch">
      <input type="checkbox" id="ms-engage-toggle" />
      <span class="ms-slider"></span>
    </label>
  </div>
  <div class="ms-sidekick-row">
    <button class="ms-sidekick-btn ms-phone-btn" id="ms-sidekick-btn" title="One click: shrink Chrome to a phone-sized strip on the right edge of your screen, hide all of TikTok's nav/buttons/captions so only the video shows, and auto-start scrolling. Work on the rest of your screen while TikTok plays.">📱 Phone Mode</button>
    <button class="ms-sidekick-btn" id="ms-popout-btn" title="Open TikTok in a NEW narrow window instead of resizing this one. Use if you want your current tabs to stay full-size.">🪟 New Window</button>
  </div>
  <div class="ms-actions">
    <button class="ms-receipt-btn" id="ms-receipt-btn">📊 Receipt</button>
    <button class="ms-stop" id="ms-stop">⏹ Stop</button>
  </div>
  <button class="ms-reset-btn" id="ms-reset-btn" title="Reset everything: opens TikTok content preferences in a new tab (where you can 'Refresh your For You feed') and clears Mood Scroll's training history so the next mode locks in faster.">🔄 Reset algo</button>
</div>
      `}function je(){if(!l)return;const e=l.getElementById("ms-toggle"),t=l.getElementById("ms-panel"),a=l.getElementById("ms-close"),r=l.getElementById("ms-custom-wrap"),s=l.getElementById("ms-custom-input"),n=l.getElementById("ms-engage-toggle"),m=l.getElementById("ms-stop"),p=l.getElementById("ms-receipt-btn");e.addEventListener("click",()=>{t.classList.toggle("open")}),a.addEventListener("click",()=>t.classList.remove("open")),l.querySelectorAll(".ms-mode").forEach(h=>{h.addEventListener("click",()=>{const w=h.dataset.mode;w==="custom"?(r.classList.add("show"),s.value=c,s.focus(),c?Z("custom"):B()):(r.classList.remove("show"),Z(w))})}),s.addEventListener("keydown",h=>{if(h.key==="Enter"){const w=s.value.trim();if(!w)return;c=w,chrome.storage.local.set({customDescription:w}),Z("custom")}}),s.addEventListener("blur",()=>{const h=s.value.trim();h&&h!==c&&(c=h,chrome.storage.local.set({customDescription:h}),o==="custom"&&B())}),n.checked=d,n.addEventListener("change",()=>{d=n.checked,chrome.storage.local.set({autoEngage:d})}),m.addEventListener("click",()=>{o=null,chrome.storage.local.set({currentMode:null}),B()}),p.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"open_receipt"}).catch(()=>{})});const g=l.getElementById("ms-reset-btn");g&&g.addEventListener("click",async()=>{y.length=0,k="training",T=0,A=0,M=null,H.clear(),x.length=0,await chrome.runtime.sendMessage({type:"reset_session"}).catch(()=>{}),ce(),de(),F(!0,"algo reset"),chrome.runtime.sendMessage({type:"open_tiktok_settings"}).catch(()=>{})});const S=l.getElementById("ms-sidekick-btn");S&&S.addEventListener("click",async()=>{const h=window.screen.availWidth,w=window.screen.availHeight;v?(await chrome.runtime.sendMessage({type:"sidekick_off",screenW:h,screenH:w}).catch(()=>{}),v=!1,He(),chrome.storage.local.set({sidekickActive:!1})):(await chrome.runtime.sendMessage({type:"sidekick_on",screenW:h,screenH:w}).catch(()=>{}),v=!0,ye(),chrome.storage.local.set({sidekickActive:!0}),o||Z("auto_scroll"),t.classList.remove("open")),B()});const L=l.getElementById("ms-popout-btn");L&&L.addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"pop_out_side",screenW:window.screen.availWidth,screenH:window.screen.availHeight}).catch(()=>{}),t.classList.remove("open")})}function Z(e){o=e,chrome.storage.local.set({currentMode:e}),M=null,le(),B()}function B(){if(!l)return;const e=l.getElementById("ms-toggle"),t=l.getElementById("ms-toggle-icon"),a=l.getElementById("ms-active-line"),r=l.getElementById("ms-active-text"),s=l.getElementById("ms-custom-wrap"),n=l.getElementById("ms-sidekick-btn");if(!(!e||!t||!a||!r||!s)){if(l.querySelectorAll(".ms-mode").forEach(m=>{const p=m.dataset.mode;m.classList.toggle("active",p===o)}),o){const m=I.find(p=>p.id===o);e.classList.add("active"),t.textContent=(m==null?void 0:m.emoji)||"✨",a.classList.add("show"),o==="custom"?(r.textContent=`Custom — "${c||"(empty)"}"`,s.classList.add("show")):o==="auto_scroll"?r.textContent="Auto Scroll · every 5s":r.textContent=(m==null?void 0:m.label)||o}else e.classList.remove("active"),t.textContent="✨",a.classList.remove("show");n&&(n.classList.toggle("active",v),n.textContent=v?"✕ Exit Phone Mode":"📱 Phone Mode")}}function F(e,t){if(!l)return;const a=l.getElementById("ms-flash");a&&(o==="auto_scroll"?(a.textContent=`⏩ ${t}`,a.className="ms-flash show match"):(a.textContent=e?`MATCH · ${t}`:`SKIP · ${t}`,a.className="ms-flash show "+(e?"match":"skip")),setTimeout(()=>a.classList.remove("show"),1800))}function ve(e){y.push(e),y.length>V&&y.shift();const t=y.filter(Boolean).length,a=y.length?t/y.length:0;let r=k;if(k==="training"&&y.length>=5&&a>=_e?r="stable":k==="stable"&&a<Ne&&(r="training"),r!==k){const s=k;k=r,console.log("[MoodScroll] phase →",k,`(${t}/${y.length})`),s==="training"&&r==="stable"&&qe()}ce()}function qe(){if(!l)return;const e=l.getElementById("ms-locked-banner");if(!e)return;const t=I.find(r=>r.id===o),a=o==="custom"?`"${c||"Custom"}"`:((t==null?void 0:t.label)||o||"").toUpperCase();e.querySelector(".ms-locked-title").textContent=`${a} LOCKED IN`,e.classList.add("show"),setTimeout(()=>e.classList.remove("show"),4e3)}function ce(){if(!l)return;const e=l.getElementById("ms-phase"),t=l.getElementById("ms-phase-label"),a=l.getElementById("ms-phase-stat"),r=l.getElementById("ms-phase-fill");if(!e||!t||!a||!r)return;if(!o||o==="auto_scroll"){e.classList.remove("show");return}e.classList.add("show");const s=y.filter(Boolean).length,n=y.length?Math.round(s/y.length*100):0;k==="training"?(e.classList.remove("stable"),t.textContent="Training the algo",a.textContent=`${s}/${y.length||0} matched`):(e.classList.add("stable"),t.textContent=`Tuned · ${n}% on-target`,a.textContent="auto pace"),r.style.width=`${n}%`}function le(){k="training",y.length=0,ce()}async function de(){if(l)try{const{session:e}=await chrome.storage.local.get("session"),t=(e==null?void 0:e.watched)||0,a=(e==null?void 0:e.skipped)||0,r=(e==null?void 0:e.startedAt)||Date.now(),s=Math.floor((Date.now()-r)/1e3),n=Math.floor(s/60),m=s%60,p=l.getElementById("ms-watched"),g=l.getElementById("ms-skipped"),S=l.getElementById("ms-timer");p&&(p.textContent=String(t)),g&&(g.textContent=String(a)),S&&(S.textContent=`${n}:${String(m).padStart(2,"0")}`)}catch{}}let me=null;const Ge=new MutationObserver(()=>{me||(me=window.setTimeout(()=>{me=null,(!D||!document.documentElement.contains(D))&&re()},250))});document.documentElement&&(re(),Ge.observe(document.documentElement,{childList:!0})),document.addEventListener("DOMContentLoaded",()=>re(),{once:!0}),setInterval(de,1e3),setInterval(()=>{if(!o||o==="auto_scroll"||T===0||Date.now()<T)return;const e=_();if(!e){T=0,A=0;return}T=0,A=0,N(e.currentSrc)},250);let ee=!1,W=null;setInterval(async()=>{var a,r,s,n;if(o!=="auto_scroll"){W=null;return}if(ee)return;const e=_();if(!e)return;const t=e.currentSrc;if(W!==t){W=t,ee=!0;try{const m=e.closest(i.itemSelector),p=m||document,g=((r=(a=p.querySelector(i.captionSelector))==null?void 0:a.textContent)==null?void 0:r.trim())||"";if(we(m,g)){F(!1,"sponsored ad"),chrome.runtime.sendMessage({type:"tally",category:"other",matched:!1}).catch(()=>{}),N(t),ee=!1,W=null;return}const S=Array.from(g.matchAll(/#([\w]+)/g)).map(f=>f[1]),L=((n=(s=p.querySelector(i.audioSelector))==null?void 0:s.textContent)==null?void 0:n.trim())||"",h=p.querySelector(i.creatorSelector),w=((h==null?void 0:h.getAttribute("href"))||"").replace(/^\/@/,"@").split("?")[0]||"unknown",pe=await ue(e),j=await chrome.runtime.sendMessage({type:"classify",frames:pe?[pe]:[],caption:g,hashtags:S,sound:L,creator:w,mode:"other"}).catch(()=>null),z=(j==null?void 0:j.category)||"other",q=be(z,e);T=Date.now()+q,F(!0,`${z} · ${Math.round(q/1e3)}s`),chrome.runtime.sendMessage({type:"tally",category:z,matched:!0}).catch(()=>{}),d&&Ee(t,!0),console.log(`[MoodScroll] auto-scroll: ${z}, holding ${q}ms`)}catch{T=Date.now()+5e3}finally{ee=!1}return}Date.now()>=T&&(N(t),W=null)},500),setInterval(async()=>{var e,t,a,r;try{if(!o||b||o==="auto_scroll"||o==="custom"&&!c||Date.now()-C<ne().decisionIntervalMs)return;const s=_();if(!s||s.currentSrc===M)return;b=!0;const n=s.currentSrc,m=o,p=s.closest(i.itemSelector),g=p||document,S=((t=(e=g.querySelector(i.captionSelector))==null?void 0:e.textContent)==null?void 0:t.trim())||"",L=Array.from(S.matchAll(/#([\w]+)/g)).map(u=>u[1]),h=((r=(a=g.querySelector(i.audioSelector))==null?void 0:a.textContent)==null?void 0:r.trim())||"",w=g.querySelector(i.creatorSelector),j=((w==null?void 0:w.getAttribute("href"))||"").replace(/^\/@/,"@").split("?")[0]||"unknown";if(o!=="custom"&&!S&&j==="unknown"){b=!1;return}if(we(p,S)){chrome.runtime.sendMessage({type:"tally",category:"other",matched:!1}).catch(()=>{}),M=n,C=Date.now(),b=!1,F(!1,"📣 sponsored ad"),console.log("[MoodScroll] SKIP sponsored ad"),N(n);return}const z=Q.has(o||"")?[]:Re[o||""]||[],q=L.map(u=>u.toLowerCase());if(z.length&&z.some(u=>q.includes(u.toLowerCase()))){const u=z.find(E=>q.includes(E.toLowerCase()));chrome.runtime.sendMessage({type:"tally",category:"other",matched:!1}).catch(()=>{}),M=n,C=Date.now(),b=!1,F(!1,`pre-skip #${u}`),ve(!1),console.log("[MoodScroll] INSTANT SKIP via negative hashtag",`#${u}`,"for",o),N(n);return}let f=null;if(o!=="custom"&&!Q.has(o||"")){const u=Ce(S,L,h);if(u.confidence>=.8&&u.category){const E=I.find(oe=>oe.id===o),$=(E==null?void 0:E.matches)??[];$.includes(u.category)||(f={category:u.category,confidence:u.confidence},console.log(`[MoodScroll] Tier1 confident SKIP: ${u.category} ∉ [${$.join(",")}]`))}}if(!f){const u=ne().useFrames||o==="custom"||Q.has(o||"");let E=[];if(u){if(E=await We(s),E.length===0){const U=await ue(s);U&&(E=[U])}}else{const U=await ue(s);U&&(E=[U])}const $=await chrome.runtime.sendMessage({type:"classify",frames:E,caption:S,hashtags:L,sound:h,creator:j,mode:o,customDescription:o==="custom"?c:void 0}),oe=_();if(!oe||oe.currentSrc!==n){b=!1;return}if($!=null&&$.error){console.warn("[MoodScroll] Gemini error:",$.error),b=!1;return}f=$;const Me=new Set(["larp","baddies","brain_rot"]).has(o||"")?.3:Q.has(o||"")?.4:.6;f&&typeof f.confidence=="number"&&f.confidence<Me&&(console.log(`[MoodScroll] Low confidence (${f.confidence} < ${Me}) → demoting to 'other'`),f={...f,category:"other"})}if(!f){b=!1;return}const ge=I.find(u=>u.id===o),Ye=(ge==null?void 0:ge.matches)??[],te=o==="custom"?typeof f.matches_mode=="boolean"?f.matches_mode:!1:Ye.includes(f.category);chrome.runtime.sendMessage({type:"tally",category:f.category,matched:te}).catch(()=>{}),M=n,C=Date.now(),b=!1;const Ie=_();if(!Ie||Ie.currentSrc!==n){console.log("[MoodScroll] video advanced before decision applied, dropping");return}if(F(te,f.category),ve(te),!te)console.log("[MoodScroll] SKIP:",f.category,"|",f.reason||""),N(n);else{const u=_(),E=be(f.category,u);T=Date.now()+E,A=0,console.log(`[MoodScroll] MATCH: ${f.category}, holding ${E}ms (dur=${u==null?void 0:u.duration}s) | ${f.reason||""}`),d&&Ee(n,!0)}}catch(s){console.error("[MoodScroll] loop error:",s),b=!1}},i.tickIntervalMs);function _(){const e=document.querySelectorAll(i.videoSelector);if(!e.length)return null;const t=window.innerHeight/2;let a=null,r=1/0;for(const s of e){const n=s.getBoundingClientRect();if(n.height<i.minVideoHeight||n.bottom<0||n.top>window.innerHeight||!s.currentSrc)continue;const m=(n.top+n.bottom)/2,p=Math.abs(m-t);p<r&&(r=p,a=s)}return a}function ke(){return Array.from(document.querySelectorAll(i.itemSelector))}function Ve(e){for(const t of ke()){const a=t.querySelector("video");if(a&&a.currentSrc===e)return t}return null}function we(e,t){if(!e)return!1;const a=['[data-e2e="ad-info"]','[data-e2e="video-ad"]','[data-e2e="ad-card"]','[data-e2e="ad-overlay"]','[data-e2e="ad-tag"]','[data-e2e="branded-content-tag"]','[data-e2e="paid-partnership-tag"]'];for(const m of a)if(e.querySelector(m))return!0;const r=e.textContent||"";if(/(^|\s)(Sponsored|Promoted|Advertisement|Paid partnership)(\s|$|\.|,)/i.test(r)||/#(ad|sponsored|spon|paidpromotion|paidpartnership|partnership|brandpartner|sponsoredpost|brandeddeal|advertorial)\b/i.test(t))return!0;const n=['button[data-e2e*="ad-button" i]','a[data-e2e*="ad-link" i]','a[href*="utm_source=tiktok"]'];for(const m of n)if(e.querySelector(m))return!0;return!1}function xe(e){if(e.readyState<2)return null;try{const t=document.createElement("canvas");t.width=480,t.height=854;const a=t.getContext("2d");return a?(a.drawImage(e,0,0,t.width,t.height),t.toDataURL("image/jpeg",.75)):null}catch{return null}}async function ue(e){let t=xe(e);if(t)return t;try{await e.play().catch(()=>{})}catch{}for(let a=0;a<5;a++)if(await new Promise(r=>setTimeout(r,200)),t=xe(e),t)return t;return null}async function We(e){const t=[],a=[0,600,600],r=e.currentSrc;for(const s of a){if(s>0&&await new Promise(n=>setTimeout(n,s)),e.paused||e.readyState<2||e.currentSrc!==r)break;try{const n=document.createElement("canvas");n.width=480,n.height=854;const m=n.getContext("2d");if(!m)continue;m.drawImage(e,0,0,n.width,n.height),t.push(n.toDataURL("image/jpeg",.75))}catch(n){console.warn("[MoodScroll] frame capture failed:",n)}}return t}function N(e){Se(e),setTimeout(()=>{const t=_();t&&t.currentSrc===e&&Se(e)},400)}function Se(e){const t=ke(),a=Ve(e)||t.find(s=>{const n=s.getBoundingClientRect();return n.top<window.innerHeight/2&&n.bottom>window.innerHeight/2});if(a&&t.length){const s=t.indexOf(a),n=s>=0?t[s+1]:null;if(n){n.scrollIntoView({behavior:"smooth",block:"center"});return}}const r=document.getElementById(i.scrollContainerId);if(r){r.scrollBy({top:r.clientHeight,behavior:"smooth"});return}window.scrollBy({top:window.innerHeight,behavior:"smooth"})}function Ee(e,t=!1){if(H.has(e)||!t&&Math.random()>ne().likeProbability)return;const a=Date.now();for(;x.length&&a-x[0]>i.likeRateLimitWindowMs;)x.shift();if(x.length>=i.likeRateLimitMax){console.log("[MoodScroll] like rate-limit reached, skipping");return}const r=t?800+Math.random()*600:i.likeDelayMinMs+Math.random()*i.likeDelayJitterMs;setTimeout(()=>{const s=_();if(!s||s.currentSrc!==e)return;const m=s.closest(i.itemSelector)||document,p=m.querySelector(i.likeIconSelector),g=(p==null?void 0:p.closest("button"))||m.querySelector(i.likeAriaSelector);if(((g==null?void 0:g.getAttribute("aria-label"))||"").toLowerCase().startsWith("unlike")||(g==null?void 0:g.getAttribute("aria-pressed"))==="true"){H.add(e);return}const L=Ue(s);let h=!1;g&&(g.click(),h=!0),H.add(e),x.push(Date.now()),console.log(`[MoodScroll] ❤️ liked match (dblclick=${L}, btn=${h})`)},r)}function Ue(e){try{const t=e.getBoundingClientRect(),a=t.left+t.width/2,r=t.top+t.height/2,s={bubbles:!0,cancelable:!0,clientX:a,clientY:r,button:0,buttons:1,view:window};return e.dispatchEvent(new MouseEvent("mousedown",s)),e.dispatchEvent(new MouseEvent("mouseup",s)),e.dispatchEvent(new MouseEvent("click",s)),setTimeout(()=>{e.dispatchEvent(new MouseEvent("mousedown",s)),e.dispatchEvent(new MouseEvent("mouseup",s)),e.dispatchEvent(new MouseEvent("click",s)),e.dispatchEvent(new MouseEvent("dblclick",s))},80),!0}catch(t){return console.warn("[MoodScroll] double-tap failed:",t),!1}}}},Y=(fe=(he=globalThis.browser)==null?void 0:he.runtime)!=null&&fe.id?globalThis.browser:globalThis.chrome;function K(i,...o){}const Ae={debug:(...i)=>K(console.debug,...i),log:(...i)=>K(console.log,...i),warn:(...i)=>K(console.warn,...i),error:(...i)=>K(console.error,...i)},J=class J extends Event{constructor(o,c){super(J.EVENT_NAME,{}),this.newUrl=o,this.oldUrl=c}};O(J,"EVENT_NAME",ae("wxt:locationchange"));let se=J;function ae(i){var o;return`${(o=Y==null?void 0:Y.runtime)==null?void 0:o.id}:content:${i}`}function De(i){let o,c;return{run(){o==null&&(c=new URL(location.href),o=i.setInterval(()=>{let d=new URL(location.href);d.href!==c.href&&(window.dispatchEvent(new se(d,c)),c=d)},1e3))}}}const G=class G{constructor(o,c){O(this,"isTopFrame",window.self===window.top);O(this,"abortController");O(this,"locationWatcher",De(this));O(this,"receivedMessageIds",new Set);this.contentScriptName=o,this.options=c,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(o){return this.abortController.abort(o)}get isInvalid(){return Y.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(o){return this.signal.addEventListener("abort",o),()=>this.signal.removeEventListener("abort",o)}block(){return new Promise(()=>{})}setInterval(o,c){const d=setInterval(()=>{this.isValid&&o()},c);return this.onInvalidated(()=>clearInterval(d)),d}setTimeout(o,c){const d=setTimeout(()=>{this.isValid&&o()},c);return this.onInvalidated(()=>clearTimeout(d)),d}requestAnimationFrame(o){const c=requestAnimationFrame((...d)=>{this.isValid&&o(...d)});return this.onInvalidated(()=>cancelAnimationFrame(c)),c}requestIdleCallback(o,c){const d=requestIdleCallback((...v)=>{this.signal.aborted||o(...v)},c);return this.onInvalidated(()=>cancelIdleCallback(d)),d}addEventListener(o,c,d,v){var b;c==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(b=o.addEventListener)==null||b.call(o,c.startsWith("wxt:")?ae(c):c,d,{...v,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Ae.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:G.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(o){var b,C,M;const c=((b=o.data)==null?void 0:b.type)===G.SCRIPT_STARTED_MESSAGE_TYPE,d=((C=o.data)==null?void 0:C.contentScriptName)===this.contentScriptName,v=!this.receivedMessageIds.has((M=o.data)==null?void 0:M.messageId);return c&&d&&v}listenForNewerScripts(o){let c=!0;const d=v=>{if(this.verifyScriptStartedEvent(v)){this.receivedMessageIds.add(v.data.messageId);const b=c;if(c=!1,b&&(o!=null&&o.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",d),this.onInvalidated(()=>removeEventListener("message",d))}};O(G,"SCRIPT_STARTED_MESSAGE_TYPE",ae("wxt:content-script-started"));let ie=G;function Qe(){}function X(i,...o){}const Be={debug:(...i)=>X(console.debug,...i),log:(...i)=>X(console.log,...i),warn:(...i)=>X(console.warn,...i),error:(...i)=>X(console.error,...i)};return(async()=>{try{const{main:i,...o}=Le,c=new ie("content",o);return await i(c)}catch(i){throw Be.error('The content script "content" crashed on startup!',i),i}})()}();
content;

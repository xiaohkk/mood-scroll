var content=function(){"use strict";var Ue=Object.defineProperty;var Ye=(z,S,O)=>S in z?Ue(z,S,{enumerable:!0,configurable:!0,writable:!0,value:O}):z[S]=O;var N=(z,S,O)=>Ye(z,typeof S!="symbol"?S+"":S,O);var de,me;function z(a){return a}const S=[{id:"auto_scroll",emoji:"⏩",label:"Auto Scroll",matches:[]},{id:"brain_rot",emoji:"🧠💀",label:"Brain Rot",matches:["brain_rot","food_porn"]},{id:"cooking",emoji:"🍳",label:"Cooking",matches:["cooking"]},{id:"laugh",emoji:"😂",label:"Laugh",matches:["comedy"]},{id:"larp",emoji:"💎",label:"LARP",matches:["larp"]},{id:"fitness",emoji:"💪",label:"Fitness",matches:["fitness"]},{id:"baddies",emoji:"💅",label:"Baddies",matches:["baddies"]},{id:"custom",emoji:"✨",label:"Custom",matches:[]}],O=new Set(["fyp","foryoupage","foryou","viral","trending","parati","xyzbca"]),Me={cooking:{keywords:["recipe","how to make","how to cook","ingredients:","preheat","simmer for","sauté","whisk together","fold in","minutes at","stir in","bake at"],hashtags:["cookingtiktok","easyrecipe","recipevideo","cookingclass","cheflife","kitchenhacks"]},educational:{keywords:["how to","tutorial","explained","tip:","did you know","pro tip","lesson","fact:","in this video"],hashtags:["learnontiktok","edutok","studytok","didyouknow","sciencetok","history","tutorial"]},comedy:{keywords:["skit","pov:","when you","when my","me when","tell me without telling me","pov when"],hashtags:["comedy","funny","humor","jokes","meme","lmao"]},fitness:{keywords:["shirtless","pump","pump cover","gym session","workout","deadlift","squat","bench press","chest day","back day","leg day","arm day","lifting","gainz","shredded","physique","natty","mens physique","bodybuilding","cutting","bulking","reps","sets","rep range","gym pr","six pack","aesthetic gym","gym flex","flexing muscle"],hashtags:["gymtok","fittok","fitness","gymrat","bodybuilding","physique","gainz","gym","gymflex","shredded","mensphysique","womensphysique","natty","lifting","fitfam","fitspo","workout","gymmotivation","gymlife","chestday","backday","legday","pumpcover","sixpack","aestheticgym","gymbros","gymtransformation"]},baddies:{keywords:["baddie","bad bitch","pretty privilege","glam","glow up","outfit of the day","ootd","fit check","feeling cute","baddie aesthetic","gym girl","fit girl","gym fit","how she walks","just girls"],hashtags:["baddie","baddies","baddietok","baddievibes","baddieaesthetic","badbitch","badbitchenergy","fitgirl","fitgirls","gymgirl","gymgirls","gymbaddie","glam","glamour","glammakeup","ootd","fashiongirl","fashionista","fitcheck","fitcheckdaily","glowup","glowupchallenge","instabaddie","baddiesonly","thatgirl","cleangirl","cleangirlaesthetic","softgirl","gymgirlaesthetic","gymgirlfit"]},motivational:{keywords:["grind","success","never give up","mindset","discipline","hustle","mentality"],hashtags:["motivation","sigma","mindset","success","entrepreneur","inspiration"]},brain_rot:{keywords:["skibidi","skibidi toilet","sigma","gigachad","gyatt","rizz","ohio","fanum","mewing","looksmax","looksmaxxing","subway surfers","minecraft parkour","ai voice","ai narrator","ai voiceover","peter griffin","family guy edit","stewie","spongebob edit","simpsons edit","anime edit","animeedit"],hashtags:["skibidi","skibiditoilet","brainrot","sigma","sigmaedit","sigmamale","gigachad","gyatt","rizz","ohio","fanumtax","mewing","looksmaxxing","aigenerated","aivoice","aivideo","aishorts","airelaxing","familyguy","familyguyedit","peterstewieedit","petergriffin","spongebob","spongebobedit","simpsonsedit","rickandmorty","phonk","phonky","phonkedit","phonkmusic","animeedit","animeedits","manhwa","manhwaedit","subwaysurfers","minecraftparkour","parkour","edit","edits","cope","slop","sloppost","ragebait"]},wholesome:{keywords:["rescued","wholesome","made my day","good news"],hashtags:["wholesome","cute","feelgood","adoption","kindness"]},food_porn:{keywords:[],hashtags:["foodporn","food","yummy","tasty","foodie"]},larp:{keywords:["lamborghini","lambo","ferrari","mclaren","rolls royce","bentley","aventador","huracan","urus","g wagon","g-wagon","g63","rolex","patek philippe","audemars piguet","richard mille","birkin","louis vuitton","hermes bag","gucci flex","secured the bag","first million","made my first million","luxury lifestyle","i'm rich","i'm so rich","rich kid","private jet","mansion tour","penthouse tour","andrew tate","tristan tate","iman gadzhi","tai lopez","grant cardone","alpha male","sigma grindset","high value man"],hashtags:["lambo","lamborghini","ferrari","mclaren","bentley","rollsroyce","supercar","supercars","exoticcars","exoticcar","sportscar","sportscars","luxurycar","luxurycars","aventador","huracan","urus","gwagon","g63","rolex","rolexwatch","patekphilippe","audemarspiguet","richardmille","luxurywatches","birkin","hermesbirkin","louisvuitton","gucciflex","luxurylifestyle","richlife","millionairelifestyle","billionairelifestyle","millionaire","billionaire","andrewtate","tristantate","sigmamale","alphamale","sigmagrindset","sigmaedit","highvalueman","imanagadzhi","tailopez","grantcardone","flex","moneyflex","getrichquick","privatejet","oldmoney","newmoney","hustlegrindset"]},startup:{keywords:["startup","founder","y combinator"," yc ","seed round","series a","mvp","product market fit","pmf","fundraising","pitch deck","launching","building in public","saas","indie hacker"],hashtags:["startup","startups","founder","founders","ycombinator","yc","startuplife","entrepreneur","saas","indiehackers","buildinpublic","techstartup","siliconvalley","techtok"]}};function Ce(a,t,c){const d=t.map(E=>E.toLowerCase().replace(/^#/,"")).filter(E=>!O.has(E)),f=((a||"")+" "+(c||"")).toLowerCase(),h={};for(const[E,w]of Object.entries(Me)){let b=0;for(const j of w.keywords)f.includes(j)&&(b+=2);for(const j of w.hashtags)d.includes(j)&&(b+=3);b>0&&(h[E]=b)}const C=Object.entries(h).sort((E,w)=>w[1]-E[1]);if(!C.length)return{category:null,confidence:0};const[I,F]=C[0];return{category:I,confidence:Math.min(F/6,.95)}}const Te={matches:["https://www.tiktok.com/*"],main(){const a={videoSelector:"video",itemSelector:'[data-e2e="recommend-list-item-container"]',captionSelector:'[data-e2e="video-desc"]',audioSelector:'[data-e2e="video-music"]',creatorSelector:'a[href^="/@"]',likeIconSelector:'[data-e2e="like-icon"]',likeAriaSelector:'button[aria-label*="Like" i]',scrollContainerId:"column-list-container",minVideoHeight:200,decisionIntervalMs:1500,tickIntervalMs:500,likeDelayMinMs:4e3,likeDelayJitterMs:3e3,likeProbability:.55,likeRateLimitWindowMs:36e5,likeRateLimitMax:20};let t=null,c="",d=!0,f=!1,h=!1,C=0,I=null;const F=new Set,E=[];let w="training";const b=[],j=10,Be=.6,_e=.4,Ne={decisionIntervalMs:300,likeProbability:1,useFrames:!1},ze={decisionIntervalMs:2500,likeProbability:.3,useFrames:!0},se=()=>w==="training"?Ne:ze,Oe={brain_rot:2500,food_porn:4e3,baddies:5e3,comedy:5500,fitness:7e3,larp:7500,motivational:8e3,wholesome:7500,wind_down:9e3,cooking:1e4,news_politics:11e3,educational:13e3,startup:13e3,drama_storytime:15e3,other:6e3};function $e(e){return Oe[e||"other"]||6e3}function ue(e,o){const s=$e(e),r=o!=null&&o.duration&&isFinite(o.duration)?Math.floor(o.duration*1e3):0;return r>0&&r<s?Math.max(2500,r-500):s}let A=0;const ae=new Set(["larp","baddies","fitness","brain_rot"]),Pe={startup:["dance","dancing","makeup","beauty","fashion","outfit","nails","hair","asmr","slime","satisfying","cat","cats","dog","dogs","pets","animals","food","foodporn","cooking","recipe","foodtok","restaurant","workout","gym","gymtok","fitness","bodybuilding","pov","skit","comedy","funny","meme","humor","jokes","prank","storytime","gossip","drama","tea","relationship","sports","football","basketball","soccer","nba","nfl","music","song","singing","dance challenge","lifehack","travel","wedding","gaming","minecraft","fortnite"],learn:["dance","makeup","beauty","fashion","outfit","nails","comedy","funny","meme","humor","jokes","pov","skit","asmr","slime","satisfying","prank","storytime","gossip","drama","tea","relationship","gaming","sports","wedding","travel"],cooking:["dance","makeup","beauty","fashion","outfit","nails","workout","gym","fitness","bodybuilding","startup","business","finance","crypto","stocks","asmr","slime","sleep","pov","skit","comedy","funny","meme","prank","gaming","sports","music","singing","travel","wedding","tutorial"],laugh:["recipe","cooking","foodtok","workout","gym","fitness","cardio","tutorial","study","studytok","history","science","edu","startup","business","finance","investing","crypto","news","politics","asmr","sleep","wholesome"],hype:["asmr","slime","sleep","wholesome","cooking","recipe","foodtok","startup","tutorial","study","sad","cry","breakup","gossip","drama","storytime","news","politics","gaming"],wind_down:["workout","gym","fitness","cardio","hiit","hustle","grind","startup","business","finance","comedy","meme","prank","funny","news","politics","sports","gaming","fortnite","minecraft","dance challenge","shock","fight"],brain_rot:["startup","business","finance","tutorial","study","history","science","edu","learnontiktok","news","politics","documentary"],food_porn:["dance","workout","gym","startup","finance","tutorial","study","history","science","sports","gaming","news","politics","comedy","skit","pov"],larp:["cooking","recipe","foodtok","dance","dancing","makeup","beauty","nails","hair","comedy","meme","skit","prank","tutorial","study","history","science","edu","gaming","minecraft","fortnite","asmr","slime","sleep","wholesome","news","politics"],fitness:["cooking","recipe","foodtok","startup","business","finance","crypto","tutorial","study","history","science","edu","gaming","minecraft","fortnite","asmr","slime","sleep","wholesome","news","politics","comedy","meme","skit","prank","dance challenge"],baddies:["cooking","recipe","foodtok","startup","business","finance","crypto","tutorial","study","history","science","edu","gaming","minecraft","fortnite","asmr","slime","sleep","news","politics","wholesome","family"]};chrome.storage.local.get(["currentMode","customDescription","autoEngage","sidekickActive"]).then(e=>{t=e.currentMode||null,c=e.customDescription||"",d=e.autoEngage!==!1,f=!!e.sidekickActive,f&&pe(),L()}),chrome.runtime.onMessage.addListener(e=>{e.type==="set_mode"&&(t=e.mode,I=null,ne(),L()),e.type==="stop"&&(t=null,I=null,ne(),L())});function pe(){if(document.getElementById("moodscroll-sidekick-css"))return;const e=document.createElement("style");e.id="moodscroll-sidekick-css",e.textContent=`
        /* HARD HIDES: all nav + header chrome */
        [data-e2e="nav-foryou"], [data-e2e="nav-following"], [data-e2e="nav-explore"],
        [data-e2e="nav-live"], [data-e2e="nav-shop"], [data-e2e="nav-profile"],
        [data-e2e="nav-upload"], [data-e2e="nav-more-menu"], [data-e2e="nav-search"],
        [data-e2e="search-box"], [data-e2e="search-box-button"],
        [data-e2e="top-login-button"], [data-e2e="top-right-action-bar-get-coin"],
        [data-e2e="tiktok-logo"],
        /* Right-side engagement column (like/comment/share/follow/save) */
        [data-e2e="like-icon"], [data-e2e="like-count"],
        [data-e2e="comment-icon"], [data-e2e="comment-count"],
        [data-e2e="share-icon"], [data-e2e="share-count"],
        [data-e2e="favorite-icon"], [data-e2e="favorite-count"],
        [data-e2e="feed-follow"], [data-e2e="video-author-avatar"],
        [data-e2e="more-menu-icon"], [data-e2e="see-more-icon"],
        /* Caption / music / desc overlays */
        [data-e2e="video-desc"], [data-e2e="video-music"], [data-e2e="capcut-tag"],
        [data-e2e^="desc-span"], [data-e2e="copyright"],
        /* Sidebars + the whole left column */
        [class*="DivSideNavContainer"], [class*="DivHeaderContainer"],
        [class*="DivLeftContainer"], [class*="DivSidebarContainer"],
        [class*="DivTabMenuContainer"], aside, header {
          display: none !important; width: 0 !important; height: 0 !important;
        }
        /* Compress horizontal margins so video fills the window */
        #column-list-container, [class*="DivColumnL"] {
          margin: 0 auto !important; padding: 0 !important;
        }
        body, html {
          background: #000 !important;
        }
        /* Strip TikTok's gradient overlays that darken the bottom of the video */
        [class*="DivBottomShadow"], [class*="DivVideoInfoContainer"],
        [class*="DivVideoCardContainer"] > div[class*="DivBottom"] {
          display: none !important;
        }
        /* Mood Scroll's own collapsed button stays visible (z-index 2^31) */
      `,document.head.appendChild(e)}function He(){var e;(e=document.getElementById("moodscroll-sidekick-css"))==null||e.remove()}let T=null,l=null;function ie(){T&&document.documentElement.contains(T)||(T=document.createElement("div"),T.id="moodscroll-overlay-root",T.style.cssText="all: initial; position: fixed; inset: 0; z-index: 2147483647; pointer-events: none;",l=T.attachShadow({mode:"open"}),l.innerHTML=Re(),document.documentElement.appendChild(T),Fe(),L(),fe())}function Re(){return`
<style>
  :host {
    all: initial;
    font-family: -apple-system, BlinkMacSystemFont, 'SF Pro Display', 'SF Pro Text', system-ui, sans-serif;
    --bg-base: rgba(22, 22, 24, 0.78);
    --bg-elevated: rgba(255, 255, 255, 0.05);
    --bg-elevated-hover: rgba(255, 255, 255, 0.09);
    --border-subtle: rgba(255, 255, 255, 0.08);
    --border-strong: rgba(255, 255, 255, 0.16);
    --text-primary: rgba(255, 255, 255, 0.95);
    --text-secondary: rgba(255, 255, 255, 0.58);
    --text-tertiary: rgba(255, 255, 255, 0.36);
    --accent: #ffd75a;
    --accent-rich: linear-gradient(180deg, #ffe07a 0%, #ffc83d 100%);
    --success: #34d399;
    --success-rich: linear-gradient(180deg, #4ade80 0%, #22c55e 100%);
    --danger: #f87171;
    --danger-rich: linear-gradient(180deg, #fb7185 0%, #e11d48 100%);
    --purple: #a78bfa;
    --purple-rich: linear-gradient(180deg, #c4b5fd 0%, #8b5cf6 100%);
    --spring: cubic-bezier(0.32, 1.45, 0.6, 1);
    --ease: cubic-bezier(0.4, 0, 0.2, 1);
  }
  * { box-sizing: border-box; font-family: inherit; -webkit-font-smoothing: antialiased; }

  /* ---------- FLOATING TOGGLE ---------- */
  .ms-toggle {
    position: fixed; bottom: 80px; right: 20px; width: 52px; height: 52px;
    border-radius: 50%;
    background: linear-gradient(180deg, rgba(50,50,55,0.85), rgba(22,22,24,0.85));
    color: var(--text-primary);
    border: 0.5px solid rgba(255,255,255,0.18);
    cursor: pointer; font-size: 22px; line-height: 1;
    box-shadow:
      inset 0 1px 0 rgba(255,255,255,0.12),
      inset 0 -1px 0 rgba(0,0,0,0.3),
      0 8px 24px rgba(0,0,0,0.5),
      0 1px 2px rgba(0,0,0,0.3);
    transition: transform 0.25s var(--spring), box-shadow 0.25s var(--ease), background 0.25s var(--ease);
    display: flex; align-items: center; justify-content: center;
    pointer-events: auto;
    backdrop-filter: blur(24px) saturate(180%);
    -webkit-backdrop-filter: blur(24px) saturate(180%);
  }
  .ms-toggle:hover { transform: translateY(-2px) scale(1.05); box-shadow: inset 0 1px 0 rgba(255,255,255,0.15), inset 0 -1px 0 rgba(0,0,0,0.3), 0 12px 32px rgba(0,0,0,0.6); }
  .ms-toggle:active { transform: scale(0.95); }
  .ms-toggle.active {
    background: var(--accent-rich);
    color: #1a1500; border-color: rgba(255, 217, 90, 0.5);
    box-shadow:
      0 0 0 4px rgba(255, 217, 90, 0.12),
      0 8px 32px rgba(255, 217, 90, 0.35),
      inset 0 1px 0 rgba(255,255,255,0.4);
  }
  .ms-toggle .ms-pulse {
    position: absolute; inset: -8px; border-radius: 50%;
    border: 1.5px solid var(--accent); opacity: 0; pointer-events: none;
    animation: msPulse 2.4s var(--ease) infinite;
  }
  .ms-toggle.active .ms-pulse { opacity: 1; }
  @keyframes msPulse {
    0% { transform: scale(0.85); opacity: 0.9; }
    100% { transform: scale(1.6); opacity: 0; }
  }

  /* ---------- DECISION FLASH ---------- */
  .ms-flash {
    position: fixed; bottom: 148px; right: 20px;
    padding: 9px 16px; border-radius: 100px;
    font-size: 11.5px; font-weight: 600; letter-spacing: -0.01em;
    pointer-events: none; opacity: 0;
    transform: translateY(8px);
    transition: all 0.4s var(--spring);
    backdrop-filter: blur(20px) saturate(180%);
    box-shadow: 0 8px 24px rgba(0,0,0,0.35);
    border: 0.5px solid rgba(255,255,255,0.15);
  }
  .ms-flash.show { opacity: 1; transform: translateY(0); }
  .ms-flash.match { background: var(--success-rich); color: #042818; }
  .ms-flash.skip { background: var(--danger-rich); color: #ffffff; }

  /* ---------- LOCKED-IN CELEBRATION BANNER ---------- */
  .ms-locked-banner {
    position: fixed; top: 50%; left: 50%;
    transform: translate(-50%, -50%) scale(0.85);
    background: linear-gradient(180deg, rgba(20, 50, 32, 0.95), rgba(15, 35, 22, 0.95));
    color: #4ade80;
    border: 1px solid rgba(74, 222, 128, 0.4);
    border-radius: 20px; padding: 28px 40px;
    box-shadow: 0 0 0 4px rgba(74, 222, 128, 0.12), 0 32px 80px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.08);
    backdrop-filter: blur(28px) saturate(180%);
    -webkit-backdrop-filter: blur(28px) saturate(180%);
    pointer-events: none; opacity: 0;
    z-index: 2147483647;
    transition: opacity 0.5s var(--ease), transform 0.6s var(--spring);
    text-align: center; min-width: 320px;
  }
  .ms-locked-banner.show { opacity: 1; transform: translate(-50%, -50%) scale(1); }
  .ms-locked-icon { font-size: 56px; line-height: 1; margin-bottom: 10px; }
  .ms-locked-title { font-size: 22px; font-weight: 700; letter-spacing: -0.02em;
    background: linear-gradient(180deg, #fff, #4ade80); -webkit-background-clip: text;
    -webkit-text-fill-color: transparent; margin-bottom: 6px; }
  .ms-locked-sub { font-size: 13px; color: rgba(255,255,255,0.65); letter-spacing: -0.005em; }

  /* ---------- PANEL ---------- */
  .ms-panel {
    position: fixed; bottom: 148px; right: 20px; width: 304px;
    background: var(--bg-base);
    color: var(--text-primary);
    border: 0.5px solid var(--border-subtle);
    border-radius: 18px; padding: 16px 14px 14px;
    box-shadow:
      0 0 0 0.5px rgba(0,0,0,0.5),
      0 40px 100px -10px rgba(0,0,0,0.75),
      inset 0 0.5px 0 rgba(255,255,255,0.07);
    backdrop-filter: blur(48px) saturate(200%);
    -webkit-backdrop-filter: blur(48px) saturate(200%);
    display: none; pointer-events: auto;
    transform-origin: bottom right;
    opacity: 0; transform: translateY(8px) scale(0.96);
    transition: opacity 0.28s var(--ease), transform 0.32s var(--spring);
  }
  .ms-panel.open { display: block; opacity: 1; transform: translateY(0) scale(1); }

  .ms-header {
    display: flex; justify-content: space-between; align-items: center;
    margin-bottom: 2px;
  }
  .ms-title {
    font-size: 15px; font-weight: 600; letter-spacing: -0.02em;
    color: var(--text-primary);
  }
  .ms-close {
    background: rgba(255,255,255,0.06);
    color: var(--text-tertiary); border: none; cursor: pointer;
    font-size: 13px; line-height: 1; padding: 0;
    width: 22px; height: 22px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    transition: all 0.18s var(--ease);
  }
  .ms-close:hover { background: rgba(255,255,255,0.14); color: var(--text-primary); }
  .ms-subtitle {
    font-size: 11px; color: var(--text-tertiary);
    margin-bottom: 12px; letter-spacing: -0.005em;
  }

  /* ---------- MODE GRID ---------- */
  .ms-grid {
    display: grid; grid-template-columns: 1fr 1fr; gap: 5px; margin-bottom: 10px;
  }
  .ms-mode {
    background: rgba(255,255,255,0.04);
    color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle);
    border-radius: 9px; padding: 9px 9px;
    cursor: pointer;
    display: flex; align-items: center; gap: 7px;
    font-size: 11.5px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease), transform 0.16s var(--spring);
  }
  .ms-mode:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }
  .ms-mode:active { transform: scale(0.97); }
  .ms-mode.active {
    background: linear-gradient(180deg, #ffe07a 0%, #ffc83d 100%);
    color: #1a1500;
    border-color: transparent;
    box-shadow: 0 2px 10px rgba(255, 217, 90, 0.28), inset 0 1px 0 rgba(255,255,255,0.4);
    font-weight: 600;
  }
  .ms-emoji { font-size: 15px; line-height: 1; flex-shrink: 0; }
  .ms-label { font-size: 11.5px; }

  /* ---------- CUSTOM INPUT ---------- */
  .ms-custom-wrap { margin-bottom: 12px; display: none; }
  .ms-custom-wrap.show { display: block; animation: msSlideDown 0.32s var(--spring); }
  @keyframes msSlideDown { from { opacity: 0; transform: translateY(-6px); max-height: 0; } to { opacity: 1; transform: translateY(0); max-height: 80px; } }
  .ms-custom-input {
    width: 100%; padding: 11px 13px;
    background: rgba(255,255,255,0.05); color: var(--text-primary);
    border: 0.5px solid var(--border-subtle);
    border-radius: 10px; font-size: 13px;
    font-family: inherit; letter-spacing: -0.01em;
    box-sizing: border-box;
    transition: all 0.2s var(--ease);
  }
  .ms-custom-input::placeholder { color: var(--text-tertiary); }
  .ms-custom-input:focus {
    outline: none; border-color: var(--accent);
    background: rgba(255,255,255,0.08);
    box-shadow: 0 0 0 3px rgba(255, 217, 90, 0.1);
  }
  .ms-custom-hint {
    font-size: 10.5px; color: var(--text-tertiary);
    margin-top: 6px; padding-left: 2px; letter-spacing: -0.005em;
  }

  /* ---------- ACTIVE LINE ---------- */
  .ms-active-line {
    font-size: 11px; padding: 8px 11px;
    background: rgba(52,211,153,0.07); color: var(--success);
    border: 0.5px solid rgba(52,211,153,0.18);
    border-radius: 9px; margin-bottom: 10px;
    letter-spacing: -0.005em; display: none;
  }
  .ms-active-line.show { display: block; }
  .ms-active-line b { color: white; font-weight: 600; }

  /* ---------- PHASE INDICATOR ---------- */
  .ms-phase {
    background: rgba(255,255,255,0.04);
    border: 0.5px solid var(--border-subtle);
    border-radius: 12px; padding: 10px 12px; margin-bottom: 12px;
    display: none;
  }
  .ms-phase.show { display: block; }
  .ms-phase-row {
    display: flex; justify-content: space-between; align-items: center;
    font-size: 11.5px; margin-bottom: 7px; letter-spacing: -0.01em;
  }
  .ms-phase-label {
    color: var(--text-primary); font-weight: 500;
    display: flex; align-items: center; gap: 6px;
  }
  .ms-phase-label::before {
    content: ''; width: 6px; height: 6px; border-radius: 50%;
    background: var(--accent); box-shadow: 0 0 8px var(--accent);
    animation: msBlink 1.4s ease-in-out infinite;
  }
  .ms-phase.stable .ms-phase-label::before {
    background: var(--success); box-shadow: 0 0 8px var(--success); animation: none;
  }
  @keyframes msBlink { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
  .ms-phase-stat { color: var(--text-tertiary); font-variant-numeric: tabular-nums; font-size: 11px; }
  .ms-phase-bar {
    height: 4px; background: rgba(255,255,255,0.08); border-radius: 100px; overflow: hidden;
  }
  .ms-phase-fill {
    height: 100%; width: 0%;
    background: linear-gradient(90deg, var(--accent), var(--success));
    border-radius: 100px;
    transition: width 0.6s var(--ease);
  }
  .ms-phase.stable .ms-phase-fill { background: var(--success); }

  /* ---------- STATS — minimal inline strip ---------- */
  .ms-stats {
    display: flex; justify-content: space-between;
    padding: 7px 4px;
    margin-bottom: 10px;
    font-size: 10.5px; color: var(--text-tertiary);
    letter-spacing: 0;
    border-top: 0.5px solid var(--border-subtle);
    border-bottom: 0.5px solid var(--border-subtle);
  }
  .ms-stat-cell {
    display: flex; align-items: baseline; gap: 4px;
  }
  .ms-stat-cell b {
    color: var(--text-primary); font-weight: 600; font-size: 12px;
    font-variant-numeric: tabular-nums; letter-spacing: -0.015em;
  }
  .ms-stat-cell span { font-size: 10.5px; color: var(--text-tertiary); }

  /* ---------- ENGAGE TOGGLE ROW ---------- */
  .ms-toggle-row {
    display: flex; align-items: center; justify-content: space-between;
    font-size: 11px; padding: 3px 2px; margin-bottom: 10px;
    color: var(--text-secondary); letter-spacing: -0.005em;
  }
  .ms-switch { position: relative; display: inline-block; width: 30px; height: 18px; }
  .ms-switch input { opacity: 0; width: 0; height: 0; }
  .ms-slider {
    position: absolute; cursor: pointer; inset: 0;
    background: rgba(255,255,255,0.12);
    border-radius: 18px; transition: background 0.22s var(--ease);
  }
  .ms-slider::before {
    position: absolute; content: ""; height: 14px; width: 14px;
    left: 2px; top: 2px; background: white;
    border-radius: 50%; transition: transform 0.26s var(--spring);
    box-shadow: 0 1px 3px rgba(0,0,0,0.35);
  }
  input:checked + .ms-slider { background: var(--success); }
  input:checked + .ms-slider::before { transform: translateX(12px); }

  /* ---------- LAYOUT BUTTONS ---------- */
  .ms-sidekick-row { display: grid; grid-template-columns: 1.6fr 1fr; gap: 5px; margin-bottom: 6px; }
  .ms-sidekick-btn {
    padding: 9px 6px;
    background: rgba(255,255,255,0.04); color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle); border-radius: 8px;
    cursor: pointer; font-family: inherit;
    font-size: 11px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease);
  }
  /* The primary Phone Mode button — slightly bigger, accent-colored */
  .ms-phone-btn {
    background: rgba(255, 217, 90, 0.08) !important;
    color: var(--accent) !important;
    border-color: rgba(255, 217, 90, 0.22) !important;
    font-weight: 600 !important;
  }
  .ms-phone-btn:hover {
    background: rgba(255, 217, 90, 0.14) !important;
    border-color: rgba(255, 217, 90, 0.4) !important;
  }
  .ms-phone-btn.active {
    background: linear-gradient(180deg, #ffe07a, #ffc83d) !important;
    color: #1a1500 !important;
    border-color: transparent !important;
    box-shadow: 0 2px 10px rgba(255, 217, 90, 0.28), inset 0 1px 0 rgba(255,255,255,0.35);
  }
  .ms-sidekick-btn:hover {
    background: rgba(167, 139, 250, 0.09); color: var(--purple);
    border-color: rgba(167, 139, 250, 0.25);
  }
  .ms-sidekick-btn.active:not(.ms-phone-btn) {
    background: linear-gradient(180deg, #c4b5fd, #8b5cf6); color: white;
    border-color: transparent;
    box-shadow: 0 2px 10px rgba(167, 139, 250, 0.28), inset 0 1px 0 rgba(255,255,255,0.22);
  }

  /* ---------- ACTIONS ---------- */
  .ms-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; }
  .ms-stop, .ms-receipt-btn {
    padding: 8px;
    background: rgba(255,255,255,0.04); color: var(--text-secondary);
    border: 0.5px solid var(--border-subtle); border-radius: 8px;
    cursor: pointer; font-family: inherit;
    font-size: 11px; font-weight: 500; letter-spacing: -0.005em;
    transition: background 0.18s var(--ease), color 0.18s var(--ease), border-color 0.18s var(--ease);
  }
  .ms-receipt-btn:hover { background: rgba(255,255,255,0.08); color: var(--text-primary); }
  .ms-stop:hover {
    background: rgba(248,113,113,0.09); color: var(--danger);
    border-color: rgba(248,113,113,0.25);
  }
</style>
<button class="ms-toggle" id="ms-toggle" title="Mood Scroll — click to open"><span class="ms-pulse"></span><span id="ms-toggle-icon">✨</span></button>
<div class="ms-flash" id="ms-flash"></div>
<div class="ms-locked-banner" id="ms-locked-banner">
  <div class="ms-locked-icon">🎯</div>
  <div class="ms-locked-title">LOCKED IN</div>
  <div class="ms-locked-sub">Algorithm tuned · scrolling at natural pace</div>
</div>
<div class="ms-panel" id="ms-panel">
  <div class="ms-header">
    <span class="ms-title">Mood Scroll</span>
    <button class="ms-close" id="ms-close">×</button>
  </div>
  <div class="ms-subtitle">pick a mood — i'll filter the feed</div>
  <div class="ms-grid">${S.map(o=>`<button class="ms-mode" data-mode="${o.id}"><span class="ms-emoji">${o.emoji}</span><span class="ms-label">${o.label}</span></button>`).join("")}</div>
  <div class="ms-custom-wrap" id="ms-custom-wrap">
    <input class="ms-custom-input" id="ms-custom-input" type="text" placeholder="describe what you want..." maxlength="200" />
    <div class="ms-custom-hint">enter to activate · examples: "startup founders", "60s rock", "golden retrievers"</div>
  </div>
  <div class="ms-active-line" id="ms-active-line">Active: <b id="ms-active-text"></b></div>
  <div class="ms-phase" id="ms-phase">
    <div class="ms-phase-row">
      <span class="ms-phase-label" id="ms-phase-label">Training the algo</span>
      <span class="ms-phase-stat" id="ms-phase-stat">0/0 matched</span>
    </div>
    <div class="ms-phase-bar"><div class="ms-phase-fill" id="ms-phase-fill"></div></div>
  </div>
  <div class="ms-stats">
    <div class="ms-stat-cell"><b id="ms-timer">0:00</b></div>
    <div class="ms-stat-cell"><b id="ms-watched">0</b><span>watched</span></div>
    <div class="ms-stat-cell"><b id="ms-skipped">0</b><span>skipped</span></div>
  </div>
  <div class="ms-toggle-row">
    <span>train algo (auto-like matches)</span>
    <label class="ms-switch">
      <input type="checkbox" id="ms-engage-toggle" />
      <span class="ms-slider"></span>
    </label>
  </div>
  <div class="ms-sidekick-row">
    <button class="ms-sidekick-btn ms-phone-btn" id="ms-sidekick-btn" title="One click: shrink Chrome to a phone-sized strip on the right edge of your screen, hide all of TikTok's nav/buttons/captions so only the video shows, and auto-start scrolling. Work on the rest of your screen while TikTok plays.">📱 Phone Mode</button>
    <button class="ms-sidekick-btn" id="ms-popout-btn" title="Open TikTok in a NEW narrow window instead of resizing this one. Use if you want your current tabs to stay full-size.">🪟 New Window</button>
  </div>
  <div class="ms-actions">
    <button class="ms-receipt-btn" id="ms-receipt-btn">📊 Receipt</button>
    <button class="ms-stop" id="ms-stop">⏹ Stop</button>
  </div>
</div>
      `}function Fe(){if(!l)return;const e=l.getElementById("ms-toggle"),o=l.getElementById("ms-panel"),s=l.getElementById("ms-close"),r=l.getElementById("ms-custom-wrap"),n=l.getElementById("ms-custom-input"),i=l.getElementById("ms-engage-toggle"),m=l.getElementById("ms-stop"),u=l.getElementById("ms-receipt-btn");e.addEventListener("click",()=>{o.classList.toggle("open")}),s.addEventListener("click",()=>o.classList.remove("open")),l.querySelectorAll(".ms-mode").forEach(y=>{y.addEventListener("click",()=>{const k=y.dataset.mode;k==="custom"?(r.classList.add("show"),n.value=c,n.focus(),c?J("custom"):L()):(r.classList.remove("show"),J(k))})}),n.addEventListener("keydown",y=>{if(y.key==="Enter"){const k=n.value.trim();if(!k)return;c=k,chrome.storage.local.set({customDescription:k}),J("custom")}}),n.addEventListener("blur",()=>{const y=n.value.trim();y&&y!==c&&(c=y,chrome.storage.local.set({customDescription:y}),t==="custom"&&L())}),i.checked=d,i.addEventListener("change",()=>{d=i.checked,chrome.storage.local.set({autoEngage:d})}),m.addEventListener("click",()=>{t=null,chrome.storage.local.set({currentMode:null}),L()}),u.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"open_receipt"}).catch(()=>{})});const v=l.getElementById("ms-sidekick-btn");v&&v.addEventListener("click",async()=>{const y=window.screen.availWidth,k=window.screen.availHeight;f?(await chrome.runtime.sendMessage({type:"sidekick_off",screenW:y,screenH:k}).catch(()=>{}),f=!1,He(),chrome.storage.local.set({sidekickActive:!1})):(await chrome.runtime.sendMessage({type:"sidekick_on",screenW:y,screenH:k}).catch(()=>{}),f=!0,pe(),chrome.storage.local.set({sidekickActive:!0}),t||J("auto_scroll"),o.classList.remove("open")),L()});const x=l.getElementById("ms-popout-btn");x&&x.addEventListener("click",async()=>{await chrome.runtime.sendMessage({type:"pop_out_side",screenW:window.screen.availWidth,screenH:window.screen.availHeight}).catch(()=>{}),o.classList.remove("open")})}function J(e){t=e,chrome.storage.local.set({currentMode:e}),I=null,ne(),L()}function L(){if(!l)return;const e=l.getElementById("ms-toggle"),o=l.getElementById("ms-toggle-icon"),s=l.getElementById("ms-active-line"),r=l.getElementById("ms-active-text"),n=l.getElementById("ms-custom-wrap"),i=l.getElementById("ms-sidekick-btn");if(!(!e||!o||!s||!r||!n)){if(l.querySelectorAll(".ms-mode").forEach(m=>{const u=m.dataset.mode;m.classList.toggle("active",u===t)}),t){const m=S.find(u=>u.id===t);e.classList.add("active"),o.textContent=(m==null?void 0:m.emoji)||"✨",s.classList.add("show"),t==="custom"?(r.textContent=`Custom — "${c||"(empty)"}"`,n.classList.add("show")):t==="auto_scroll"?r.textContent="Auto Scroll · every 5s":r.textContent=(m==null?void 0:m.label)||t}else e.classList.remove("active"),o.textContent="✨",s.classList.remove("show");i&&(i.classList.toggle("active",f),i.textContent=f?"✕ Exit Phone Mode":"📱 Phone Mode")}}function q(e,o){if(!l)return;const s=l.getElementById("ms-flash");s&&(t==="auto_scroll"?(s.textContent=`⏩ ${o}`,s.className="ms-flash show match"):(s.textContent=e?`MATCH · ${o}`:`SKIP · ${o}`,s.className="ms-flash show "+(e?"match":"skip")),setTimeout(()=>s.classList.remove("show"),1800))}function ge(e){b.push(e),b.length>j&&b.shift();const o=b.filter(Boolean).length,s=b.length?o/b.length:0;let r=w;if(w==="training"&&b.length>=5&&s>=Be?r="stable":w==="stable"&&s<_e&&(r="training"),r!==w){const n=w;w=r,console.log("[MoodScroll] phase →",w,`(${o}/${b.length})`),n==="training"&&r==="stable"&&je()}he()}function je(){if(!l)return;const e=l.getElementById("ms-locked-banner");if(!e)return;const o=S.find(r=>r.id===t),s=t==="custom"?`"${c||"Custom"}"`:((o==null?void 0:o.label)||t||"").toUpperCase();e.querySelector(".ms-locked-title").textContent=`${s} LOCKED IN`,e.classList.add("show"),setTimeout(()=>e.classList.remove("show"),4e3)}function he(){if(!l)return;const e=l.getElementById("ms-phase"),o=l.getElementById("ms-phase-label"),s=l.getElementById("ms-phase-stat"),r=l.getElementById("ms-phase-fill");if(!e||!o||!s||!r)return;if(!t||t==="auto_scroll"){e.classList.remove("show");return}e.classList.add("show");const n=b.filter(Boolean).length,i=b.length?Math.round(n/b.length*100):0;w==="training"?(e.classList.remove("stable"),o.textContent="Training the algo",s.textContent=`${n}/${b.length||0} matched`):(e.classList.add("stable"),o.textContent=`Tuned · ${i}% on-target`,s.textContent="auto pace"),r.style.width=`${i}%`}function ne(){w="training",b.length=0,he()}async function fe(){if(l)try{const{session:e}=await chrome.storage.local.get("session"),o=(e==null?void 0:e.watched)||0,s=(e==null?void 0:e.skipped)||0,r=(e==null?void 0:e.startedAt)||Date.now(),n=Math.floor((Date.now()-r)/1e3),i=Math.floor(n/60),m=n%60,u=l.getElementById("ms-watched"),v=l.getElementById("ms-skipped"),x=l.getElementById("ms-timer");u&&(u.textContent=String(o)),v&&(v.textContent=String(s)),x&&(x.textContent=`${i}:${String(m).padStart(2,"0")}`)}catch{}}let re=null;const qe=new MutationObserver(()=>{re||(re=window.setTimeout(()=>{re=null,(!T||!document.documentElement.contains(T))&&ie()},250))});document.documentElement&&(ie(),qe.observe(document.documentElement,{childList:!0})),document.addEventListener("DOMContentLoaded",()=>ie(),{once:!0}),setInterval(fe,1e3),setInterval(()=>{if(!t||t==="auto_scroll"||A===0||Date.now()<A)return;const e=D();if(!e){A=0;return}A=0,$(e.currentSrc)},500);let X=!1,G=null;setInterval(async()=>{var s,r,n,i;if(t!=="auto_scroll"){G=null;return}if(X)return;const e=D();if(!e)return;const o=e.currentSrc;if(G!==o){G=o,X=!0;try{const m=e.closest(a.itemSelector),u=m||document,v=((r=(s=u.querySelector(a.captionSelector))==null?void 0:s.textContent)==null?void 0:r.trim())||"";if(ye(m,v)){q(!1,"sponsored ad"),chrome.runtime.sendMessage({type:"tally",category:"other",matched:!1}).catch(()=>{}),$(o),X=!1,G=null;return}const x=Array.from(v.matchAll(/#([\w]+)/g)).map(g=>g[1]),y=((i=(n=u.querySelector(a.audioSelector))==null?void 0:n.textContent)==null?void 0:i.trim())||"",k=u.querySelector(a.creatorSelector),W=((k==null?void 0:k.getAttribute("href"))||"").replace(/^\/@/,"@").split("?")[0]||"unknown",ce=await ke(e),P=await chrome.runtime.sendMessage({type:"classify",frames:ce?[ce]:[],caption:v,hashtags:x,sound:y,creator:W,mode:"other"}).catch(()=>null),B=(P==null?void 0:P.category)||"other",H=ue(B,e);A=Date.now()+H,q(!0,`${B} · ${Math.round(H/1e3)}s`),chrome.runtime.sendMessage({type:"tally",category:B,matched:!0}).catch(()=>{}),d&&xe(o,!0),console.log(`[MoodScroll] auto-scroll: ${B}, holding ${H}ms`)}catch{A=Date.now()+5e3}finally{X=!1}return}Date.now()>=A&&($(o),G=null)},500),setInterval(async()=>{var e,o,s,r;try{if(!t||h||t==="auto_scroll"||t==="custom"&&!c||Date.now()-C<se().decisionIntervalMs)return;const n=D();if(!n||n.currentSrc===I)return;h=!0;const i=n.currentSrc,m=t,u=n.closest(a.itemSelector),v=u||document,x=((o=(e=v.querySelector(a.captionSelector))==null?void 0:e.textContent)==null?void 0:o.trim())||"",y=Array.from(x.matchAll(/#([\w]+)/g)).map(p=>p[1]),k=((r=(s=v.querySelector(a.audioSelector))==null?void 0:s.textContent)==null?void 0:r.trim())||"",W=v.querySelector(a.creatorSelector),P=((W==null?void 0:W.getAttribute("href"))||"").replace(/^\/@/,"@").split("?")[0]||"unknown";if(t!=="custom"&&!x&&P==="unknown"){h=!1;return}if(ye(u,x)){chrome.runtime.sendMessage({type:"tally",category:"other",matched:!1}).catch(()=>{}),I=i,C=Date.now(),h=!1,q(!1,"📣 sponsored ad"),console.log("[MoodScroll] SKIP sponsored ad"),$(i);return}const B=ae.has(t||"")?[]:Pe[t||""]||[],H=y.map(p=>p.toLowerCase());if(B.length&&B.some(p=>H.includes(p.toLowerCase()))){const p=B.find(M=>H.includes(M.toLowerCase()));chrome.runtime.sendMessage({type:"tally",category:"other",matched:!1}).catch(()=>{}),I=i,C=Date.now(),h=!1,q(!1,`pre-skip #${p}`),ge(!1),console.log("[MoodScroll] INSTANT SKIP via negative hashtag",`#${p}`,"for",t),$(i);return}let g=null;if(t!=="custom"&&!ae.has(t||"")){const p=Ce(x,y,k);if(p.confidence>=.8&&p.category){const M=S.find(Z=>Z.id===t),_=(M==null?void 0:M.matches)??[];_.includes(p.category)||(g={category:p.category,confidence:p.confidence},console.log(`[MoodScroll] Tier1 confident SKIP: ${p.category} ∉ [${_.join(",")}]`))}}if(!g){const p=se().useFrames||t==="custom";let M=[];if(p)M=await We(n);else{const Ie=await ke(n);Ie&&(M=[Ie])}const _=await chrome.runtime.sendMessage({type:"classify",frames:M,caption:x,hashtags:y,sound:k,creator:P,mode:t,customDescription:t==="custom"?c:void 0}),Z=D();if(!Z||Z.currentSrc!==i){h=!1;return}if(_!=null&&_.error){console.warn("[MoodScroll] Gemini error:",_.error),h=!1;return}g=_;const Ee=new Set(["larp","baddies","brain_rot"]).has(t||"")?.3:ae.has(t||"")?.4:.6;g&&typeof g.confidence=="number"&&g.confidence<Ee&&(console.log(`[MoodScroll] Low confidence (${g.confidence} < ${Ee}) → demoting to 'other'`),g={...g,category:"other"})}if(!g){h=!1;return}const le=S.find(p=>p.id===t),Ve=(le==null?void 0:le.matches)??[],Q=t==="custom"?typeof g.matches_mode=="boolean"?g.matches_mode:!1:Ve.includes(g.category);chrome.runtime.sendMessage({type:"tally",category:g.category,matched:Q}).catch(()=>{}),I=i,C=Date.now(),h=!1;const Se=D();if(!Se||Se.currentSrc!==i){console.log("[MoodScroll] video advanced before decision applied, dropping");return}if(q(Q,g.category),ge(Q),!Q)console.log("[MoodScroll] SKIP:",g.category,"|",g.reason||""),$(i);else{const p=D(),M=ue(g.category,p);A=Date.now()+M,console.log(`[MoodScroll] MATCH: ${g.category}, holding ${M}ms (dur=${p==null?void 0:p.duration}s) | ${g.reason||""}`),d&&xe(i,!0)}}catch(n){console.error("[MoodScroll] loop error:",n),h=!1}},a.tickIntervalMs);function D(){const e=document.querySelectorAll(a.videoSelector);if(!e.length)return null;const o=window.innerHeight/2;let s=null,r=1/0;for(const n of e){const i=n.getBoundingClientRect();if(i.height<a.minVideoHeight||i.bottom<0||i.top>window.innerHeight||!n.currentSrc)continue;const m=(i.top+i.bottom)/2,u=Math.abs(m-o);u<r&&(r=u,s=n)}return s}function be(){return Array.from(document.querySelectorAll(a.itemSelector))}function Ge(e){for(const o of be()){const s=o.querySelector("video");if(s&&s.currentSrc===e)return o}return null}function ye(e,o){if(!e)return!1;const s=['[data-e2e="ad-info"]','[data-e2e="video-ad"]','[data-e2e="ad-card"]','[data-e2e="ad-overlay"]','[data-e2e="ad-tag"]','[data-e2e="branded-content-tag"]','[data-e2e="paid-partnership-tag"]'];for(const m of s)if(e.querySelector(m))return!0;const r=e.textContent||"";if(/(^|\s)(Sponsored|Promoted|Advertisement|Paid partnership)(\s|$|\.|,)/i.test(r)||/#(ad|sponsored|spon|paidpromotion|paidpartnership|partnership|brandpartner|sponsoredpost|brandeddeal|advertorial)\b/i.test(o))return!0;const i=['button[data-e2e*="ad-button" i]','a[data-e2e*="ad-link" i]','a[href*="utm_source=tiktok"]'];for(const m of i)if(e.querySelector(m))return!0;return!1}function ve(e){if(e.readyState<2)return null;try{const o=document.createElement("canvas");o.width=360,o.height=640;const s=o.getContext("2d");return s?(s.drawImage(e,0,0,o.width,o.height),o.toDataURL("image/jpeg",.6)):null}catch{return null}}async function ke(e){let o=ve(e);if(o)return o;try{await e.play().catch(()=>{})}catch{}for(let s=0;s<5;s++)if(await new Promise(r=>setTimeout(r,200)),o=ve(e),o)return o;return null}async function We(e){const o=[],s=[0,600,600],r=e.currentSrc;for(const n of s){if(n>0&&await new Promise(i=>setTimeout(i,n)),e.paused||e.readyState<2||e.currentSrc!==r)break;try{const i=document.createElement("canvas");i.width=360,i.height=640;const m=i.getContext("2d");if(!m)continue;m.drawImage(e,0,0,i.width,i.height),o.push(i.toDataURL("image/jpeg",.6))}catch(i){console.warn("[MoodScroll] frame capture failed:",i)}}return o}function $(e){we(e),setTimeout(()=>{const o=D();o&&o.currentSrc===e&&we(e)},400)}function we(e){const o=be(),s=Ge(e)||o.find(n=>{const i=n.getBoundingClientRect();return i.top<window.innerHeight/2&&i.bottom>window.innerHeight/2});if(s&&o.length){const n=o.indexOf(s),i=n>=0?o[n+1]:null;if(i){i.scrollIntoView({behavior:"smooth",block:"center"});return}}const r=document.getElementById(a.scrollContainerId);if(r){r.scrollBy({top:r.clientHeight,behavior:"smooth"});return}window.scrollBy({top:window.innerHeight,behavior:"smooth"})}function xe(e,o=!1){if(F.has(e)||!o&&Math.random()>se().likeProbability)return;const s=Date.now();for(;E.length&&s-E[0]>a.likeRateLimitWindowMs;)E.shift();if(E.length>=a.likeRateLimitMax){console.log("[MoodScroll] like rate-limit reached, skipping");return}const r=o?800+Math.random()*600:a.likeDelayMinMs+Math.random()*a.likeDelayJitterMs;setTimeout(()=>{const n=D();if(!n||n.currentSrc!==e)return;const m=n.closest(a.itemSelector)||document;let u=null;const v=m.querySelector(a.likeIconSelector);if(v&&(u=v.closest("button")),u||(u=m.querySelector(a.likeAriaSelector)),!u){console.log("[MoodScroll] like button not found");return}if((u.getAttribute("aria-label")||"").toLowerCase().startsWith("unlike")||u.getAttribute("aria-pressed")==="true"){F.add(e);return}u.click(),F.add(e),E.push(Date.now()),console.log("[MoodScroll] ❤️ liked match")},r)}}},V=(me=(de=globalThis.browser)==null?void 0:de.runtime)!=null&&me.id?globalThis.browser:globalThis.chrome;function U(a,...t){}const Le={debug:(...a)=>U(console.debug,...a),log:(...a)=>U(console.log,...a),warn:(...a)=>U(console.warn,...a),error:(...a)=>U(console.error,...a)},K=class K extends Event{constructor(t,c){super(K.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=c}};N(K,"EVENT_NAME",te("wxt:locationchange"));let ee=K;function te(a){var t;return`${(t=V==null?void 0:V.runtime)==null?void 0:t.id}:content:${a}`}function Ae(a){let t,c;return{run(){t==null&&(c=new URL(location.href),t=a.setInterval(()=>{let d=new URL(location.href);d.href!==c.href&&(window.dispatchEvent(new ee(d,c)),c=d)},1e3))}}}const R=class R{constructor(t,c){N(this,"isTopFrame",window.self===window.top);N(this,"abortController");N(this,"locationWatcher",Ae(this));N(this,"receivedMessageIds",new Set);this.contentScriptName=t,this.options=c,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return V.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,c){const d=setInterval(()=>{this.isValid&&t()},c);return this.onInvalidated(()=>clearInterval(d)),d}setTimeout(t,c){const d=setTimeout(()=>{this.isValid&&t()},c);return this.onInvalidated(()=>clearTimeout(d)),d}requestAnimationFrame(t){const c=requestAnimationFrame((...d)=>{this.isValid&&t(...d)});return this.onInvalidated(()=>cancelAnimationFrame(c)),c}requestIdleCallback(t,c){const d=requestIdleCallback((...f)=>{this.signal.aborted||t(...f)},c);return this.onInvalidated(()=>cancelIdleCallback(d)),d}addEventListener(t,c,d,f){var h;c==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(h=t.addEventListener)==null||h.call(t,c.startsWith("wxt:")?te(c):c,d,{...f,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Le.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:R.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){var h,C,I;const c=((h=t.data)==null?void 0:h.type)===R.SCRIPT_STARTED_MESSAGE_TYPE,d=((C=t.data)==null?void 0:C.contentScriptName)===this.contentScriptName,f=!this.receivedMessageIds.has((I=t.data)==null?void 0:I.messageId);return c&&d&&f}listenForNewerScripts(t){let c=!0;const d=f=>{if(this.verifyScriptStartedEvent(f)){this.receivedMessageIds.add(f.data.messageId);const h=c;if(c=!1,h&&(t!=null&&t.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",d),this.onInvalidated(()=>removeEventListener("message",d))}};N(R,"SCRIPT_STARTED_MESSAGE_TYPE",te("wxt:content-script-started"));let oe=R;function Je(){}function Y(a,...t){}const De={debug:(...a)=>Y(console.debug,...a),log:(...a)=>Y(console.log,...a),warn:(...a)=>Y(console.warn,...a),error:(...a)=>Y(console.error,...a)};return(async()=>{try{const{main:a,...t}=Te,c=new oe("content",t);return await a(c)}catch(a){throw De.error('The content script "content" crashed on startup!',a),a}})()}();
content;

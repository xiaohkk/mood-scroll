var background=function(){"use strict";var w,b;function A(t){return t==null||typeof t=="function"?{main:t}:t}const O=`You are Mood Scroll, a real-time classifier of short-form video content on TikTok.

You receive up to 3 frames captured at 0.3s, 0.9s, and 1.5s into a video, plus its caption text, hashtags, sound name, and creator handle. Treat the frames as a sequence — content is what they collectively suggest, not what any single frame shows.

Output JSON ONLY. No prose. No markdown fences. Just the JSON object.

Schema:
{
  "category": "brain_rot" | "educational" | "comedy" | "wholesome" | "food_porn" | "cooking" | "news_politics" | "motivational" | "drama_storytime" | "wind_down" | "fitness" | "startup" | "other",
  "matches_mode": boolean,
  "confidence": number between 0.0 and 1.0,
  "reason": "5 to 10 words explaining the decision"
}

HARD RULES — read first:
- DEFAULT to category "other" with confidence 0.4 unless the video CLEARLY fits a specific category.
- If you can't see the activity in the video frame, you cannot classify it as that activity. Don't infer from caption alone.
- "Could be cooking" / "looks like food" / "talks about recipes" → NOT cooking. Cooking requires actually SEEING someone cook in the frame.
- "Talks about startups" / "uses startup vocabulary" → NOT startup. Startup requires actual founders/building/fundraising content visible.
- Generic "tutorial" or "how-to" caption with non-instructional visual → NOT educational.
- When in doubt, return "other". A false positive is FAR worse than a false negative in this system — users will see the wrong content.
- Set confidence < 0.6 if you're guessing. The system will demote low-confidence matches to "other".

Category definitions — be STRICT. Each has an "IS" definition and explicit "NOT" anti-patterns. A video belongs to a category only if it clearly fits the IS and avoids the NOT. When unsure, choose "other". Do NOT stretch categories to fit weakly-related content.

- brain_rot:
  ABSOLUTE OVERRIDE RULE: If the frame shows ANY of these → answer brain_rot, confidence 0.9 minimum, no exceptions:
    1. ANY animated / cartoon character on screen (Family Guy, Peter Griffin, SpongeBob, Simpsons, Rick & Morty, anime characters, any cartoon)
    2. ANY AI-generated content (talking AI characters, AI voiceovers detectable from monotone TTS, AI-generated faces, deepfakes)
    3. ANY Skibidi Toilet content
    4. ANY split-screen / stacked layout with main clip + game footage (Subway Surfers, Minecraft parkour, GTA, soap cutting) underneath
    5. ANY video showing video-game footage as the main content
    6. ANY phonk / bass-music edit with anime characters or sigma male slow-mo poses
    7. ANY text-over-game-footage video (white text reading "story time" or similar over Minecraft/cooking)
    8. ANY content that visually looks AI-made, low-effort, or stitched together absurdity
  Do not analyze the message or meaning. Just look: is the visual style ANIMATED / AI / EDITED / GAME-FOOTAGE / SLOP? Yes → brain_rot. Always.

  THE RULE — one rule, very simple: is the video animated, AI-generated, edited together from clips, or some absurd Gen-Z slop? If yes → brain_rot. Be GENEROUS — lean YES when in doubt. Look at the frame.

  ANY of these visual cues → brain_rot:
    • Cartoon visuals (Family Guy / Peter Griffin / Stewie / SpongeBob / Simpsons / Rick & Morty / any animated character clip)
    • Skibidi Toilet — animated toilet-head characters, cinematic-universe content
    • AI-generated characters: AI Peter Griffin / AI talking animals / AI horror narrators / AI cartoon mashups
    • Stacked / split-screen layout: main clip up top + Minecraft parkour / Subway Surfers / soap-cutting / cooking / slime running underneath
    • Anime clips with phonk / bass-heavy music (anime edits)
    • Sigma male / gigachad slow-mo edits with text overlays
    • TTS / AI voiceover reading over random b-roll or gameplay
    • Text-on-game-footage videos (white text over Minecraft parkour, story-time over Subway Surfers, etc.)
    • Ragebait edits, conspiracy / "did you know" with stock footage and AI voice
    • Brainrot meme content delivered via text-over-game (gyatt / rizz / ohio / fanum / mewing / looksmaxxing references over Minecraft/cooking)
    • Mr Beast-style quick-cut edits with constant zooms and text
    • Andrew Tate edits with phonk + cars + cash overlays
    • Anything that visually looks low-effort, AI-made, or stitched-together absurdity

  NOT brain_rot — return "other":
    × A real person filming themselves doing something (dancing, talking, vlog) → other
    × Real animals doing animal things (without AI overlay) → other or wholesome
    × A genuinely funny human sketch → comedy
    × Real cooking / fitness / tutorial → cooking / fitness / educational
    × A real podcast clip → other

  THE TEST: scan the frame. Is the visual STYLE animated, AI-generated, stitched-together, or absurd Gen-Z slop? Yes → brain_rot. Just real people doing real things? → other. Lean YES on brain_rot when in doubt — these videos are everywhere on the FYP.

- educational:
  IS: teaches a verifiable skill, fact, or concept with depth — tutorials, explainers, science, history, language, finance breakdowns.
  NOT: a makeup tutorial (that's beauty/brain_rot), a "did you know" with no substance, a generic "X simple trick" hack video.

- comedy:
  IS: genuinely funny — sketches with setup/punchline, witty reactions, absurd humor with clever editing, written jokes.
  NOT: cringe content, awkward situations played straight, mean-spirited pranks, generic POV memes without a real joke.

- wholesome:
  IS: heartwarming acts of kindness, family moments, animal rescues, reunions, paying-it-forward.
  NOT: cute cats/dogs alone (that's brain_rot), any romantic/relationship drama, sad-then-happy reaction baits.

- food_porn:
  IS: food shown for pure visual appeal — close-up plated dishes, eating ASMR, restaurant footage, food reviews. NO instruction.
  NOT: any video that shows actual recipe steps or cooking technique (that's cooking).

- cooking:
  IS: STRICT — recipe demonstration, ingredient prep, cooking technique. The video must SHOW someone cooking, with steps.
  NOT: food reviews. Restaurant b-roll. Food eating. "Talking about" a recipe. Plated finished dishes alone. Just because the caption says "recipe" does NOT make it cooking — the frame must show prep/cooking.

- news_politics:
  IS: news coverage, political commentary, current events, debate.
  NOT: a creator's emotional reaction to news without substance (that's drama_storytime).

- motivational:
  IS: genuine pep talks, training montages, success stories with substance, focused mindset content.
  NOT: generic "grind" music videos with no message. NOT bro voiceover over random gym clips.

- drama_storytime:
  IS: gossip, storytimes, internet drama recaps, "let me tell you about my day", reaction-to-news content.
  NOT: a documentary (that's educational).

- wind_down:
  IS: calming content — nature, ASMR, slow-paced lo-fi, no shouting, soft visuals.
  NOT: anything with bass drops or sudden noise. NOT motivational quotes over calm music.

- fitness:
  IS: gym + physique content. Includes:
    • Shirtless / sports-bra gym flex shots, physique reveals, "pump check" videos
    • Lifting demonstrations (deadlift, squat, bench press, OHP) with focus on form OR aesthetic
    • Bodybuilding content, men's/women's physique posing, natural lifting transformations
    • Gym session vlogs where the camera is on the body / the lift
    • "Aesthetic gym" content with bass-heavy music and slow-mo lifting
  NOT: gym vlogs that never show exercise or physique (those are other/lifestyle). NOT a baddie aesthetic gym video where the focus is the attractive woman's overall presentation (that's baddies). NOT a Tate-style flex with a Lambo (that's larp).

- baddies:
  THE RULE — common sense. Is there an attractive woman in the frame who is the focus (showing her face or body)? Yes → baddies. No → other. Don't overthink it.

  ANY of these in the frame → baddies:
    • A woman showing her face to the camera with intentional presentation (makeup done, posed, hair styled)
    • A woman showing her body (gym fit, swimwear, fashion, OOTD, fit check)
    • Gym girls — woman working out, doing weights, stretching, taking mirror selfies in gym wear
    • Fashion / outfit / "fit check" / get-ready-with-me / OOTD videos centered on a woman
    • Glam content — makeup transformations, glow-up reveals, "that girl" / "clean girl" aesthetic
    • Slow-mo walks, hair flips, model-style poses, lip-sync clips of attractive women
    • Pretty-privilege / "baddie" / "high value woman" content
    • Soft-girl, baddie aesthetic, lifestyle vlogs of attractive women
    • Dance / trend videos where the visual draw is the woman's appearance
    • Mirror selfie videos, pool/beach content, bedroom photoshoot vibes

  Be GENEROUS — when in doubt, lean YES on baddies. If there's a woman on screen who looks put-together / styled / intentional with her presentation, it's baddies.

  NOT baddies — return "other":
    × Talking head with no styling / casual / no appearance focus → other
    × Genuine makeup TUTORIAL (educational instruction) → educational
    × Food/cooking with someone in the background → cooking (if cooking) or other
    × Animated content (no real woman on screen) → brain_rot or other
    × A man on screen → other
    × A group/crowd shot where no individual woman is the focus → other

  THE TEST: do I see a woman who is clearly meant to be looked at (face/body, styled, intentional)? Yes → baddies. No → other. Lean YES when uncertain.

- startup:
  IS: STRICT — founders building/fundraising, YC/accelerators, indie hackers, SaaS, business advice specifically for founders, fundraising stories, tech entrepreneurship.
  NOT: generic finance advice. NOT career advice. NOT crypto/stock trading. NOT corporate office vlogs. NOT generic "side hustle" videos.

- larp:
  SCAN ALL FRAMES CAREFULLY: You are given up to 3 frames from different points in the video. Examine each one — foreground AND background — for any wealth markers. A luxury car parked behind the subject in one of the frames is still LARP. Don't just look at the main subject; scan the entire frame.

  ABSOLUTE OVERRIDE RULE: If you see ANY VISIBLE CASH in any frame — stacks of bills, money fan/spread, someone counting money, money rain, money gun, briefcase of cash, money on a table in front of someone, money being thrown — the answer is LARP. Always. Without exception. Confidence 0.9 minimum. Do not even consider any other category. Cash on screen is the single clearest LARP signal in the entire system.

  THE RULE — one rule, very simple: scan the visible frame for wealth markers. If you spot ANY of them — anywhere in the shot, foreground or background, briefly or prominently — the answer is larp. Do not analyze what the people are doing or saying. The video's "intent" doesn't matter. The only question: is there VISIBLE WEALTH in the frame?

  WEALTH MARKERS (any one of these in the frame = larp):
    • Any exotic/luxury car (Lambo, Ferrari, McLaren, Bentley, Rolls Royce, Porsche 911, G-Wagon, Maserati, Aston Martin, AMG, M5, vintage muscle, exotic supercar of any kind)
    • Any luxury watch (Rolex, Patek, AP, Richard Mille, Hublot, Cartier, Omega Daytona, big chunky diamond watches)
    • CASH IS ALWAYS LARP — any visible cash (stacks of bills, money fan/spread, counting money, money rain, money gun, scattered bills, briefcase of cash) → larp, no exceptions. This is the single clearest signal.
    • Designer logos (LV monogram, Gucci, Hermes orange box, Chanel double-C, Dior, Versace, Balenciaga, Prada)
    • Designer items (Birkin, bag, shoes, clothing)
    • Opulent interiors (marble, gold fixtures, chandeliers, infinity pool, sweeping staircase, oversized rooms, columns)
    • LUXURY private jet (Gulfstream, Citation, Embraer Phenom, Bombardier Global, Dassault Falcon — sleek twin-jet business aircraft), yacht (large white hull, multi-deck), helicopter, Ferrari-red Vegas hotel suite
    • Gold chains, iced-out jewelry, diamond grills, big diamond pendants
    • Casino chips, slot-machine wins, sports-book bet slips with big payouts
    • Whiskey + cigar + watch combo, classic wealth-aesthetics frames
    • Known wealth personalities on screen (Andrew Tate, Tristan Tate, Iman Gadzhi, Tai Lopez, Grant Cardone)
    • Crypto/trading screens with explicit profit numbers
    • Pet sitting near/on luxury items (cat on cash, dog with Rolex, exotic pet in a luxury setting)
    • Luxury hotel suites, first-class flight cabins
    • Anything else that visually communicates "I have money" — when in doubt, lean YES

  ONLY return "other" if the frame contains ZERO visible wealth markers (e.g. talking head against a plain wall, office vlog at a normal job, educational charts only, regular apartment).

  EXPLICITLY NOT a luxury aircraft (return "other" not larp):
    × Small prop plane (Cessna, Piper, single-engine)
    × Glider, ultralight, paraglider
    × Commercial airliner cabin or exterior (Boeing/Airbus passenger jet)
    × Inside-the-airport / TSA / boarding-pass scenes
    × Helicopter rescue / news / military
    Only LUXURY business jets and sleek private aircraft count.

  Ignore the subject and the activity. Ignore the caption. Just answer: is wealth visible? Yes → larp. No → other.

- other: anything that doesn't strongly fit one of the above with high confidence. Prefer "other" over a weak match. This is the safe default.

Mode → matching categories (set matches_mode = true if category appears in this list for the given mode):
- brain_rot: brain_rot, food_porn
- startup: startup
- learn: educational, startup
- laugh: comedy
- wind_down: wholesome, wind_down
- hype: motivational, fitness
- cooking: cooking
- custom: see CUSTOM MODE HANDLING below

CUSTOM MODE HANDLING:
When MODE is "custom", a CUSTOM_DESCRIPTION field will be present in the user message. Set matches_mode=true only if the video content genuinely matches that description based on visuals, on-screen text, caption, and hashtags.
- Be reasonably strict. Surface-level keyword overlap (e.g., a hashtag alone) is NOT enough — the video itself must be about the described topic.
- Don't be so strict that clearly relevant videos get rejected for missing one element.
- Set matches_mode=true only when your confidence is >= 0.65 that the video fits.
- Still populate "category" with the closest standard category (or "other" if none fit) — independent of the custom match decision.
- In "reason", briefly cite the evidence (e.g., "founder discussing seed round, matches startup description").

If your confidence is below 0.5 (or 0.65 for custom), err toward matches_mode = false. Skipping a maybe-match is better than wasting the user's time.`;let f=Promise.resolve();function g(t){const i=f.then(t,t);return f=i.catch(()=>{}),i}const p="https://muon-lite.up.railway.app",y="openai/gpt-4o";async function N(t){var T,S;const i=c=>c.replace(/^data:image\/jpeg;base64,/,""),u=t.mode==="custom"&&t.customDescription?`CUSTOM_DESCRIPTION: ${t.customDescription}
`:"",r=(((T=t.frames)==null?void 0:T.length)||0)>0?`The ${t.frames.length} attached image(s) are video frames captured at 0.3s, 0.9s, and 1.5s into the playback.`:"No frames attached — classify based on text metadata only.",o=`MODE: ${t.mode}
`+u+`CAPTION: "${t.caption||"none"}"
HASHTAGS: ${((S=t.hashtags)==null?void 0:S.join(" "))||"none"}
SOUND: "${t.sound||"none"}"
CREATOR: "${t.creator||"unknown"}"

${r} Classify the video per the schema in the system prompt. Return ONLY the JSON object, no prose, no markdown fences.`,s=(t.frames||[]).map(c=>({type:"image",source:{type:"base64",media_type:"image/jpeg",data:i(c)}})),e=`${(t.proxyUrl||p).replace(/\/+$/,"")}/v1/messages`,n=await fetch(e,{method:"POST",headers:{"content-type":"application/json","x-api-key":t.apiKey,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:t.model||y,max_tokens:220,temperature:0,system:O,messages:[{role:"user",content:[...s,{type:"text",text:o}]}]})});if(!n.ok){const c=await n.text();throw new Error(`Claude ${n.status}: ${c.slice(0,300)}`)}const l=await n.json(),h=Array.isArray(l==null?void 0:l.content)?l.content.find(c=>(c==null?void 0:c.type)==="text"):null,k=h==null?void 0:h.text;if(!k)throw new Error("Claude returned no text: "+JSON.stringify(l).slice(0,200));const v=k.replace(/^```(?:json)?\s*|\s*```$/g,"").trim();try{return JSON.parse(v)}catch{throw new Error("parse_failed: "+v.slice(0,200))}}async function I(t){if(!t||t==="unknown")return null;const r=((await chrome.storage.local.get("creator_memo")).creator_memo||{})[t];if(!r||r.count<2)return null;const o=Math.min(.5+r.count*.15,.9);return{category:r.category,confidence:o}}async function E(t,i){!t||t==="unknown"||await g(async()=>{const r=(await chrome.storage.local.get("creator_memo")).creator_memo||{},o=r[t];o&&o.category===i?(o.count++,o.lastSeen=Date.now()):r[t]={category:i,count:1,lastSeen:Date.now()},await chrome.storage.local.set({creator_memo:r})})}const x=A(()=>{chrome.runtime.onInstalled.addListener(o=>{o.reason==="install"&&chrome.runtime.openOptionsPage()}),chrome.runtime.onMessage.addListener((o,s,a)=>{if(o.type==="classify")return u(o).then(a).catch(e=>a({error:e.message})),!0;if(o.type==="check_memo")return I(o.creator).then(e=>a(e||{confidence:0})).catch(e=>a({confidence:0,error:e.message})),!0;if(o.type==="update_memo")return E(o.creator,o.category).then(()=>a({ok:!0})).catch(e=>a({ok:!1,error:e.message})),!0;if(o.type==="tally")return r(o.category,o.matched).then(()=>a({ok:!0})).catch(e=>a({ok:!1,error:e.message})),!0;if(o.type==="reset_session")return chrome.storage.local.set({session:null}).then(()=>a({ok:!0})).catch(e=>a({ok:!1,error:e.message})),!0;if(o.type==="open_receipt")return chrome.tabs.create({url:chrome.runtime.getURL("receipt.html")}).then(()=>a({ok:!0})).catch(e=>a({ok:!1,error:String((e==null?void 0:e.message)??e)})),!0;if(o.type==="sidekick_on")return i(!0,o.screenW,o.screenH).then(e=>a(e)).catch(e=>a({ok:!1,error:String((e==null?void 0:e.message)??e)})),!0;if(o.type==="sidekick_off")return i(!1,o.screenW,o.screenH).then(e=>a(e)).catch(e=>a({ok:!1,error:String((e==null?void 0:e.message)??e)})),!0;if(o.type==="pop_out_side")return t(o.screenW||1440,o.screenH||900).then(e=>a(e)).catch(e=>a({ok:!1,error:e.message})),!0});async function t(o,s){const e=Math.min(s-60,900),n=Math.max(0,o-440),h=await chrome.windows.create({url:"https://www.tiktok.com/foryou",type:"popup",width:440,height:e,left:n,top:40,focused:!0});return{ok:!0,windowId:h==null?void 0:h.id}}async function i(o,s=1440,a=900){const e=await chrome.windows.getCurrent();if(!e.id)return{ok:!1,error:"no current window"};if(o){const l=Math.max(500,Math.min(a-60,900));return!(await chrome.storage.local.get("sidekickPrevBounds")).sidekickPrevBounds&&e.width&&e.width>540&&await chrome.storage.local.set({sidekickPrevBounds:{width:e.width,height:e.height,left:e.left,top:e.top}}),await chrome.windows.update(e.id,{state:"normal",width:440,height:l,left:Math.max(0,s-440),top:40}),{ok:!0}}else{const{sidekickPrevBounds:n}=await chrome.storage.local.get("sidekickPrevBounds");return n?(await chrome.windows.update(e.id,n),await chrome.storage.local.remove("sidekickPrevBounds")):await chrome.windows.update(e.id,{state:"maximized"}),{ok:!0}}}async function u(o){const{apiKey:s,proxyUrl:a,model:e}=await chrome.storage.local.get(["apiKey","proxyUrl","model"]);if(!s)return{error:"No API key. Open the options page."};try{return await N({...o,apiKey:s,proxyUrl:a||p,model:e||y})}catch(n){return console.error("[MoodScroll] classify error:",n),{error:String((n==null?void 0:n.message)??n)}}}async function r(o,s){await g(async()=>{const{session:a}=await chrome.storage.local.get("session"),e=Date.now();let n=a;(!n||e-n.startedAt>6*60*60*1e3)&&(n={startedAt:e,categories:{},watched:0,skipped:0}),n.categories[o]=(n.categories[o]||0)+1,s?n.watched++:n.skipped++,await chrome.storage.local.set({session:n})})}});function _(){}(b=(w=globalThis.browser)==null?void 0:w.runtime)!=null&&b.id?globalThis.browser:globalThis.chrome;function d(t,...i){}const L={debug:(...t)=>d(console.debug,...t),log:(...t)=>d(console.log,...t),warn:(...t)=>d(console.warn,...t),error:(...t)=>d(console.error,...t)};let m;try{m=x.main(),m instanceof Promise&&console.warn("The background's main() function return a promise, but it must be synchronous")}catch(t){throw L.error("The background crashed on startup!"),t}return m}();
background;

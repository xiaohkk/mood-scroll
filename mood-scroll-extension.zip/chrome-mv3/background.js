var background=function(){"use strict";var w,k;function O(o){return o==null||typeof o=="function"?{main:o}:o}let f=Promise.resolve();function p(o){const i=f.then(o,o);return f=i.catch(()=>{}),i}const g="https://muon-lite.up.railway.app",y="openai/gpt-4o",S={larp:`You classify TikTok videos for a "LARP" filter — luxury / wealth flex content.

Look at the attached frames. Is there any visible wealth in any frame? Examples:
- Luxury car (Lambo, Ferrari, McLaren, Bentley, Rolls Royce, Porsche, G-Wagon) — even in background
- Luxury watch (Rolex, Patek, AP, Richard Mille) — wrist shot or close-up
- Cash visible (stacks, fans, money on table, counting money)
- Designer items (Birkin, LV monogram, Hermes, Chanel, Gucci)
- Mansion / penthouse interior (marble, gold, infinity pool)
- Private jet (sleek business aircraft like Gulfstream — NOT small prop planes or commercial cabins)
- Gold chains, diamond jewelry
- Andrew Tate / Tristan Tate / Iman Gadzhi on screen

CASH = always larp, confidence 0.9+. Be GENEROUS — if you see wealth, it's larp.

NOT larp: talking head with no luxury visible, normal apartment, finance education charts, regular car review.

Output JSON only: {"category": "larp" or "other", "matches_mode": boolean, "confidence": 0-1, "reason": "5 words"}`,brain_rot:`You classify TikTok videos for a "Brain Rot" filter — animated / AI / edited slop.

Look at the attached frames. Is the visual style animated, AI-generated, or stitched-together slop? Examples:
- Cartoon characters (Family Guy, Peter Griffin, SpongeBob, Simpsons, Rick & Morty, anime)
- AI-generated talking characters or AI voiceover narration
- Skibidi Toilet content
- Split-screen with game footage underneath (Subway Surfers, Minecraft parkour, soap cutting)
- Phonk / bass-music edits with anime or sigma slow-mo poses
- Text-over-game-footage videos
- Sigma male montages, gigachad edits
- Andrew Tate edits with phonk

NOT brain rot: real people just being themselves (dancing, talking, vlogging), real animals, genuine comedy with punchline.

THE TEST: animated / AI / edited / game-footage / slop? → brain_rot. Real person doing real things? → other.

Output JSON only: {"category": "brain_rot" or "other", "matches_mode": boolean, "confidence": 0-1, "reason": "5 words"}`,cooking:`You classify TikTok videos for a "Cooking" filter — actual recipe and cooking technique.

Look at the attached frames. Does the video SHOW actual cooking happening? Examples:
- Recipe steps being demonstrated, ingredient prep, cooking technique
- Someone using a stove, oven, knife, mixer, whisk
- Food being assembled, baked, fried, plated mid-cooking

NOT cooking: food reviews, eating videos, restaurant b-roll, plated finished food, anyone just talking about food without cooking it.

THE TEST: do you see someone actually cooking with technique/steps? → cooking. Just food visible? → other.

Output JSON only: {"category": "cooking" or "other", "matches_mode": boolean, "confidence": 0-1, "reason": "5 words"}`,laugh:`You classify TikTok videos for a "Laugh" filter — actually funny comedy.

Look at the attached frames + caption. Is this genuinely funny — sketch with setup/punchline, witty edit, absurd humor, clever timing?

NOT laugh: cringe content played straight, mean pranks, generic POV memes without a joke, awkward situations.

THE TEST: would a normal person genuinely laugh? → comedy. Just trying to be funny? → other.

Output JSON only: {"category": "comedy" or "other", "matches_mode": boolean, "confidence": 0-1, "reason": "5 words"}`,fitness:`You classify TikTok videos for a "Fitness" filter — gym + physique content.

Look at the attached frames. Does the video show:
- Shirtless / sports-bra physique flex, pump check, body reveal
- Lifting demonstration (deadlift, squat, bench press, OHP) with form or aesthetic focus
- Bodybuilding pose, physique transformation
- Aesthetic gym content (slow-mo lifting with bass music, body in motion)

NOT fitness: gym vlogs that don't show exercise/physique, fashion at the gym (those are baddies if female focus), Tate-style flex with money/cars (that's larp).

Output JSON only: {"category": "fitness" or "other", "matches_mode": boolean, "confidence": 0-1, "reason": "5 words"}`,baddies:`You classify TikTok videos for a "Baddies" filter — attractive women aesthetic content.

Look at the attached frames. Common sense: is there an attractive woman as the focus of the video (showing face or body with intentional styled presentation)?

- Gym girls (woman in workout fit, mirror selfie, doing exercise with aesthetic focus)
- Fashion / OOTD / fit check / GRWM videos centered on a woman
- Glam transformations, glow-ups, "that girl" / "clean girl" aesthetic
- Slow-mo walks, hair flips, model poses, lip-sync clips
- Mirror selfies, pool/beach content, bedroom photoshoot vibes

NOT baddies: man on screen, animated content, group/crowd with no focused woman, genuine makeup TUTORIAL with instruction, regular cooking with woman in background.

THE TEST: woman whose presentation is meant to be looked at? → baddies. No? → other.

Output JSON only: {"category": "baddies" or "other", "matches_mode": boolean, "confidence": 0-1, "reason": "5 words"}`,custom:`You classify a TikTok video against a USER DESCRIPTION provided in the user message.

Look at the attached frames + caption. Does the video genuinely match the user's description? Be reasonably strict — surface keyword overlap is NOT a match; the video itself must be about the described topic.

If confidence is below 0.65, return matches_mode=false.

Output JSON only: {"category": "matches_user" or "other", "matches_mode": boolean, "confidence": 0-1, "reason": "5 words"}`},_=`You categorize TikTok videos for adaptive watch duration. Return one of:
brain_rot, food_porn, comedy, cooking, fitness, larp, baddies, educational, wholesome, wind_down, motivational, news_politics, drama_storytime, other

Look at the attached frames + caption. Pick the closest single category.

Output JSON only: {"category": "<one of above>", "confidence": 0-1, "reason": "5 words"}`;async function x(o){var v;const i=c=>c.replace(/^data:image\/jpeg;base64,/,""),h=S[o.mode]||_,t=(o.mode==="custom"&&o.customDescription?`USER DESCRIPTION: ${o.customDescription}

`:"")+`Caption: ${o.caption||"(none)"}
Hashtags: ${((v=o.hashtags)==null?void 0:v.join(" "))||"(none)"}
Creator: ${o.creator||"(unknown)"}

${o.frames.length} video frame${o.frames.length===1?"":"s"} attached. Classify per the system prompt. JSON only.`,r=(o.frames||[]).map(c=>({type:"image",source:{type:"base64",media_type:"image/jpeg",data:i(c)}})),e=`${(o.proxyUrl||g).replace(/\/+$/,"")}/v1/messages`,n=await fetch(e,{method:"POST",headers:{"content-type":"application/json","x-api-key":o.apiKey,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:o.model||y,max_tokens:120,temperature:0,system:h,messages:[{role:"user",content:[...r,{type:"text",text:t}]}]})});if(!n.ok){const c=await n.text();throw new Error(`Claude ${n.status}: ${c.slice(0,300)}`)}const l=await n.json(),u=Array.isArray(l==null?void 0:l.content)?l.content.find(c=>(c==null?void 0:c.type)==="text"):null,b=u==null?void 0:u.text;if(!b)throw new Error("Claude returned no text: "+JSON.stringify(l).slice(0,200));const T=b.replace(/^```(?:json)?\s*|\s*```$/g,"").trim();try{return JSON.parse(T)}catch{throw new Error("parse_failed: "+T.slice(0,200))}}async function P(o){if(!o||o==="unknown")return null;const s=((await chrome.storage.local.get("creator_memo")).creator_memo||{})[o];if(!s||s.count<2)return null;const t=Math.min(.5+s.count*.15,.9);return{category:s.category,confidence:t}}async function L(o,i){!o||o==="unknown"||await p(async()=>{const s=(await chrome.storage.local.get("creator_memo")).creator_memo||{},t=s[o];t&&t.category===i?(t.count++,t.lastSeen=Date.now()):s[o]={category:i,count:1,lastSeen:Date.now()},await chrome.storage.local.set({creator_memo:s})})}const E=O(()=>{chrome.runtime.onInstalled.addListener(t=>{t.reason==="install"&&chrome.runtime.openOptionsPage(),(t.reason==="install"||t.reason==="update")&&chrome.tabs.query({url:"https://www.tiktok.com/*"},r=>{r.forEach(a=>{a.id!==void 0&&chrome.tabs.reload(a.id).catch(()=>{})})})}),chrome.runtime.onMessage.addListener((t,r,a)=>{if(t.type==="classify")return h(t).then(a).catch(e=>a({error:e.message})),!0;if(t.type==="check_memo")return P(t.creator).then(e=>a(e||{confidence:0})).catch(e=>a({confidence:0,error:e.message})),!0;if(t.type==="update_memo")return L(t.creator,t.category).then(()=>a({ok:!0})).catch(e=>a({ok:!1,error:e.message})),!0;if(t.type==="tally")return s(t.category,t.matched).then(()=>a({ok:!0})).catch(e=>a({ok:!1,error:e.message})),!0;if(t.type==="reset_session")return chrome.storage.local.set({session:null}).then(()=>a({ok:!0})).catch(e=>a({ok:!1,error:e.message})),!0;if(t.type==="open_receipt")return chrome.tabs.create({url:chrome.runtime.getURL("receipt.html")}).then(()=>a({ok:!0})).catch(e=>a({ok:!1,error:String((e==null?void 0:e.message)??e)})),!0;if(t.type==="open_tiktok_settings")return chrome.tabs.create({url:"https://www.tiktok.com/setting/content-preferences"}).then(()=>a({ok:!0})).catch(e=>a({ok:!1,error:String((e==null?void 0:e.message)??e)})),!0;if(t.type==="sidekick_on")return i(!0,t.screenW,t.screenH).then(e=>a(e)).catch(e=>a({ok:!1,error:String((e==null?void 0:e.message)??e)})),!0;if(t.type==="sidekick_off")return i(!1,t.screenW,t.screenH).then(e=>a(e)).catch(e=>a({ok:!1,error:String((e==null?void 0:e.message)??e)})),!0;if(t.type==="pop_out_side")return o(t.screenW||1440,t.screenH||900).then(e=>a(e)).catch(e=>a({ok:!1,error:e.message})),!0});async function o(t,r){const e=Math.min(r-60,900),n=Math.max(0,t-440),u=await chrome.windows.create({url:"https://www.tiktok.com/foryou",type:"popup",width:440,height:e,left:n,top:40,focused:!0});return{ok:!0,windowId:u==null?void 0:u.id}}async function i(t,r=1440,a=900){const e=await chrome.windows.getCurrent();if(!e.id)return{ok:!1,error:"no current window"};if(t){const l=Math.max(500,Math.min(a-60,900));return!(await chrome.storage.local.get("sidekickPrevBounds")).sidekickPrevBounds&&e.width&&e.width>540&&await chrome.storage.local.set({sidekickPrevBounds:{width:e.width,height:e.height,left:e.left,top:e.top}}),await chrome.windows.update(e.id,{state:"normal",width:440,height:l,left:Math.max(0,r-440),top:40}),{ok:!0}}else{const{sidekickPrevBounds:n}=await chrome.storage.local.get("sidekickPrevBounds");return n?(await chrome.windows.update(e.id,n),await chrome.storage.local.remove("sidekickPrevBounds")):await chrome.windows.update(e.id,{state:"maximized"}),{ok:!0}}}async function h(t){const{apiKey:r,proxyUrl:a,model:e}=await chrome.storage.local.get(["apiKey","proxyUrl","model"]);if(!r)return{error:"No API key. Open the options page."};try{return await x({...t,apiKey:r,proxyUrl:a||g,model:e||y})}catch(n){return console.error("[MoodScroll] classify error:",n),{error:String((n==null?void 0:n.message)??n)}}}async function s(t,r){await p(async()=>{const{session:a}=await chrome.storage.local.get("session"),e=Date.now();let n=a;(!n||e-n.startedAt>6*60*60*1e3)&&(n={startedAt:e,categories:{},watched:0,skipped:0}),n.categories[t]=(n.categories[t]||0)+1,r?n.watched++:n.skipped++,await chrome.storage.local.set({session:n})})}});function M(){}(k=(w=globalThis.browser)==null?void 0:w.runtime)!=null&&k.id?globalThis.browser:globalThis.chrome;function d(o,...i){}const N={debug:(...o)=>d(console.debug,...o),log:(...o)=>d(console.log,...o),warn:(...o)=>d(console.warn,...o),error:(...o)=>d(console.error,...o)};let m;try{m=E.main(),m instanceof Promise&&console.warn("The background's main() function return a promise, but it must be synchronous")}catch(o){throw N.error("The background crashed on startup!"),o}return m}();
background;
